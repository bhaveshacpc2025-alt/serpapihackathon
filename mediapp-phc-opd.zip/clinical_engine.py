﻿"""
clinical_engine.py - MediKiosk AYUSH & Allopathic Intelligence
"""
import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Any

# 1. PRAKRITI QUESTIONS & SCORING
PRAKRITI_QUESTIONS = [
    {
        "id": "body_frame",
        "category": "Physical",
        "question": "Body Frame & Physical Build / शारीरिक बनावट",
        "options": {
            "vata": "Lean, thin, tall/short, difficulty gaining weight (दुबला-पतला)",
            "pitta": "Medium, athletic, well-proportioned (मध्यम, सुडौल)",
            "kapha": "Broad, heavy, stocky, easily gains weight (मजबूत, भारी)"
        }
    },
    {
        "id": "skin_nature",
        "category": "Physical",
        "question": "Skin Texture & Nature / त्वचा की प्रकृति",
        "options": {
            "vata": "Dry, rough, thin, cool, chapped (रूखी, खुरदरी)",
            "pitta": "Warm, reddish/fair, sensitive, prone to acne/freckles (उष्ण, तिल/मुंहासे)",
            "kapha": "Smooth, oily, thick, moist, glowing (चिकनी, तैलीय, कोमल)"
        }
    },
    {
        "id": "appetite_agni",
        "category": "Physiological",
        "question": "Appetite & Digestion (Agni) / भूख और पाचन (अग्नि)",
        "options": {
            "vata": "Variable, irregular, frequent bloating (विषमाग्नि - अनियमित)",
            "pitta": "Sharp, intense hunger, burning sensation/acidity (तीक्ष्णाग्नि - तेज भूख, जलन)",
            "kapha": "Slow, steady appetite, heavy feeling after meal (मंदाग्नि - सुस्त, भारीपन)"
        }
    },
    {
        "id": "weather_thermal",
        "category": "Physiological",
        "question": "Temperature Tolerance / मौसम सहनशीलता",
        "options": {
            "vata": "Dislikes cold & wind, loves sunlight and heat (ठंड असहनीय)",
            "pitta": "Dislikes heat & sun, sweats easily, loves cold breeze (गर्मी असहनीय)",
            "kapha": "Dislikes damp/wet cold, comfortable in dry warmth (नम ठंड असहनीय)"
        }
    },
    {
        "id": "sleep_pattern",
        "category": "Psychological",
        "question": "Sleep Quality / नींद की स्थिति",
        "options": {
            "vata": "Light, interrupted, easily woken, dreams of movement (हल्की, बेचैन नींद)",
            "pitta": "Moderate sound sleep (6-7 hrs), wake up refreshed (मध्यम नींद)",
            "kapha": "Deep, heavy sleep (8+ hrs), difficulty waking up (गहरी, भारी नींद)"
        }
    },
    {
        "id": "stress_mind",
        "category": "Psychological",
        "question": "Mental Temperament & Stress / मानसिक स्वभाव और तनाव",
        "options": {
            "vata": "Quick to worry, anxious, restless overthinker (चिंतित, चंचल)",
            "pitta": "Ambitious, short-tempered, irritable, sharp intellect (तीक्ष्ण, क्रोधी)",
            "kapha": "Calm, patient, steady, slow to anger, loyal (शांत, धैर्यवान)"
        }
    }
]

def calculate_prakriti(answers: Dict[str, str]) -> Dict[str, Any]:
    scores = {"vata": 0, "pitta": 0, "kapha": 0}
    total = 0
    for q_id, dosha in answers.items():
        val = str(dosha).lower()
        if val in scores:
            scores[val] += 1
            total += 1

    if total == 0:
        return {
            "vata_pct": 33.3,
            "pitta_pct": 33.3,
            "kapha_pct": 33.4,
            "primary_dosha": "Balanced (Sama)",
            "secondary_dosha": "Tridoshaja",
            "constitution_type": "Tridoshaja Sama Prakriti"
        }

    v_pct = round((scores["vata"] / total) * 100, 1)
    p_pct = round((scores["pitta"] / total) * 100, 1)
    k_pct = round((scores["kapha"] / total) * 100, 1)

    sorted_doshas = sorted([("Vata", v_pct), ("Pitta", p_pct), ("Kapha", k_pct)], key=lambda x: x[1], reverse=True)
    dominant = sorted_doshas[0][0]
    secondary = sorted_doshas[1][0]

    if sorted_doshas[0][1] - sorted_doshas[1][1] < 15:
        c_type = f"{dominant}-{secondary} (Dwandwaja)"
    else:
        c_type = f"{dominant}-Dominant (Ekadoshaja)"

    return {
        "vata_pct": v_pct,
        "pitta_pct": p_pct,
        "kapha_pct": k_pct,
        "primary_dosha": dominant,
        "secondary_dosha": secondary,
        "constitution_type": c_type
    }

# 2. SMART CLINICAL ALERTS ENGINE (USP 1)
CLINICAL_RULES = [
    {
        "id": "RULE-GUGGULU-STATIN",
        "category": "Herb-Drug Interaction",
        "trigger_herbs": ["guggulu", "yograj guggulu", "kaishore guggulu", "triphala guggulu"],
        "trigger_allopathic": ["atorvastatin", "rosuvastatin", "simvastatin"],
        "severity": "High",
        "title": "Guggulu + Statin CYP3A4 Interaction",
        "rationale": "Guggulsterones can alter CYP3A4 and P-glycoprotein efflux transport, elevating systemic statin exposure.",
        "risk": "Elevated risk of statin-induced myopathy, severe muscle pain, and rare rhabdomyolysis.",
        "recommendation": "Maintain 4+ hours interval, review statin dose, or monitor serum Creatine Kinase (CK)."
    },
    {
        "id": "RULE-ASHWAGANDHA-METFORMIN",
        "category": "Herb-Drug Interaction",
        "trigger_herbs": ["ashwagandha", "withania somnifera"],
        "trigger_allopathic": ["metformin", "glimepiride", "glipizide", "insulin"],
        "severity": "Moderate",
        "title": "Additive Hypoglycemic Effect",
        "rationale": "Withanolides stimulate pancreatic insulin secretion and enhance peripheral glucose uptake.",
        "risk": "Additive reduction in blood glucose; risk of acute symptomatic hypoglycemia.",
        "recommendation": "Advise patient to monitor capillary blood sugar daily; educate on hypoglycemic warning signs."
    },
    {
        "id": "RULE-AVIPATTIKAR-DIARRHEA",
        "category": "Clinical Contraindication",
        "trigger_herbs": ["avipattikar churna", "trivrit", "haritaki", "castor oil"],
        "contraindicated_symptoms": ["diarrhea", "loose stools", "ulcerative colitis", "dysentery", "loose motions"],
        "severity": "Critical",
        "title": "Purgative / Laxative Herb Contraindication",
        "rationale": "Avipattikar Churna contains ~44% Trivrit (Operculina turpethum), an active purgative (Sukha Virechana).",
        "risk": "Exacerbates severe fluid loss, abdominal cramps, and hypokalemia in patients with active loose motions.",
        "recommendation": "Switch to mild non-laxative Pitta shamaka: Praval Pishti or Kamadudha Ras."
    },
    {
        "id": "RULE-ARJUNA-ANTISYSTEMIC",
        "category": "Herb-Drug Interaction",
        "trigger_herbs": ["arjuna", "terminalia arjuna"],
        "trigger_allopathic": ["atenolol", "metoprolol", "amlodipine", "losartan", "telmisartan"],
        "severity": "Moderate",
        "title": "Additive Hypotensive & Inotropic Potentiation",
        "rationale": "Arjuna glycosides exert positive inotropic and vasorelaxant effects synergizing with allopathic antihypertensives.",
        "risk": "May lead to transient postural dizziness, hypotension, or bradycardia.",
        "recommendation": "Monitor BP closely during the first 2 weeks; schedule follow-up."
    },
    {
        "id": "RULE-TRIPHALA-ANTICOAGULANT",
        "category": "Herb-Drug Interaction",
        "trigger_herbs": ["triphala", "garlic", "lashuna", "ginkgo biloba"],
        "trigger_allopathic": ["aspirin", "clopidogrel", "warfarin", "ecospirin"],
        "severity": "High",
        "title": "Potentiated Antiplatelet / Anticoagulant Risk",
        "rationale": "Active polyphenols and thiosulfinates inhibit platelet aggregation and may prolong coagulation cascades.",
        "risk": "Increased susceptibility to ecchymosis, petechiae, or gastrointestinal bleeding.",
        "recommendation": "Periodically assess INR/PT levels; instruct patient to report any abnormal gum bleeding or bruising."
    }
]

def check_clinical_alerts(prescriptions: List[Dict[str, str]], past_meds: List[str], symptoms: List[str]) -> List[Dict[str, Any]]:
    alerts = []
    prescribed_names = [p.get("name", "").lower() for p in prescriptions]
    past_names = [m.lower() for m in past_meds]
    all_drugs = prescribed_names + past_names
    symptom_blob = " ".join([s.lower() for s in symptoms])

    for rule in CLINICAL_RULES:
        herb_hit = None
        for herb in rule["trigger_herbs"]:
            if any(herb in drug for drug in all_drugs):
                herb_hit = herb
                break
        if not herb_hit:
            continue

        # Check allopathic interaction
        if "trigger_allopathic" in rule:
            for allo in rule["trigger_allopathic"]:
                if any(allo in drug for drug in all_drugs):
                    alerts.append({
                        "rule_id": rule["id"],
                        "category": rule["category"],
                        "severity": rule["severity"],
                        "title": rule["title"],
                        "herb_involved": herb_hit.title(),
                        "allopathic_involved": allo.title(),
                        "rationale": rule["rationale"],
                        "clinical_risk": rule["risk"],
                        "recommendation": rule["recommendation"],
                        "override_permitted": True,
                        "requires_doctor_ack": True
                    })
                    break

        # Check symptom contraindication
        if "contraindicated_symptoms" in rule:
            for bad_sym in rule["contraindicated_symptoms"]:
                if bad_sym in symptom_blob:
                    alerts.append({
                        "rule_id": rule["id"],
                        "category": rule["category"],
                        "severity": rule["severity"],
                        "title": rule["title"],
                        "herb_involved": herb_hit.title(),
                        "contraindicated_condition": bad_sym.title(),
                        "rationale": rule["rationale"],
                        "clinical_risk": rule["risk"],
                        "recommendation": rule["recommendation"],
                        "override_permitted": True,
                        "requires_doctor_ack": True
                    })
                    break

    return alerts

# 3. MEDICO-LEGAL AUDIT TRAIL ENGINE (USP 2)
def generate_audit_fingerprint(session_id: str, abha_id: str, intake_data: dict, doctor_notes: dict, prescriptions: list, timestamp: str = None) -> dict:
    if not timestamp:
        timestamp = datetime.now(timezone.utc).isoformat()

    canonical = {
        "session_id": session_id,
        "abha_id": abha_id,
        "timestamp_utc": timestamp,
        "intake_snapshot": intake_data,
        "doctor_notes": doctor_notes,
        "prescriptions": prescriptions
    }
    serialized = json.dumps(canonical, sort_keys=True, default=str)
    h = hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    return {
        "algorithm": "SHA-256",
        "fingerprint": h,
        "timestamp_utc": timestamp,
        "tamper_proof_status": "VERIFIED_IMMUTABLE",
        "payload_size_bytes": len(serialized)
    }

# 4. ABDM FHIR R4 BUNDLE GENERATOR (USP 3)
def build_abdm_fhir_r4_bundle(session_id: str, patient: dict, intake: dict, doctor: dict, prescriptions: list, audit_hash: str) -> dict:
    bundle_id = f"abdm-bundle-{uuid.uuid4().hex[:10]}"
    patient_id = f"pat-abha-{patient.get('abha_id', '910000000000').replace('-', '')}"
    comp_id = f"comp-opd-{session_id}"
    enc_id = f"enc-{session_id}"

    entries = []

    # 1. Composition
    composition = {
        "fullUrl": f"urn:uuid:{comp_id}",
        "resource": {
            "resourceType": "Composition",
            "id": comp_id,
            "status": "final",
            "type": {
                "coding": [
                    {
                        "system": "https://projecteka.in/snomed",
                        "code": "371530004",
                        "display": "Clinical consultation report"
                    }
                ],
                "text": "MediKiosk Dual AYUSH-Allopathy Consultation Record"
            },
            "subject": {"reference": f"urn:uuid:{patient_id}", "display": patient.get("name")},
            "encounter": {"reference": f"urn:uuid:{enc_id}"},
            "date": datetime.now(timezone.utc).isoformat(),
            "author": [
                {
                    "display": doctor.get("doctor_name", "Dr. V. Sharma (BAMS, MD Ayur)"),
                    "identifier": {"system": "https://doctor.abdm.gov.in", "value": doctor.get("doctor_id", "DOC-AYU-8821")}
                }
            ],
            "title": "ABDM MediKiosk Pre-Consultation & Care Plan",
            "section": [
                {"title": "Chief Complaints", "text": {"status": "generated", "div": str(intake.get("chief_complaints", []))}},
                {"title": "Ayurvedic Assessment", "text": {"status": "generated", "div": f"Prakriti: {intake.get('prakriti', {}).get('constitution_type')}, Agni: {intake.get('dashavidha', {}).get('agni')}"}},
                {"title": "Prescriptions", "text": {"status": "generated", "div": str(prescriptions)}}
            ]
        }
    }
    entries.append(composition)

    # 2. Patient
    patient_res = {
        "fullUrl": f"urn:uuid:{patient_id}",
        "resource": {
            "resourceType": "Patient",
            "id": patient_id,
            "identifier": [
                {
                    "system": "https://healthid.abdm.gov.in",
                    "value": patient.get("abha_id")
                }
            ],
            "name": [{"text": patient.get("name")}],
            "gender": patient.get("gender", "male").lower(),
            "birthDate": f"{datetime.now().year - int(patient.get('age', 35))}-01-01"
        }
    }
    entries.append(patient_res)

    # 3. Observation - Prakriti
    prakriti = intake.get("prakriti", {})
    obs_prakriti = {
        "fullUrl": f"urn:uuid:obs-prakriti-{session_id}",
        "resource": {
            "resourceType": "Observation",
            "id": f"obs-prakriti-{session_id}",
            "status": "final",
            "code": {
                "coding": [{"system": "http://ayush.gov.in/namaste", "code": "NAM-PRAKRITI", "display": "Ayurvedic Constitution"}],
                "text": "Deha Prakriti Assessment"
            },
            "subject": {"reference": f"urn:uuid:{patient_id}"},
            "valueString": prakriti.get("constitution_type", "Pitta-Vata"),
            "component": [
                {"code": {"text": "Vata Percentage"}, "valueQuantity": {"value": prakriti.get("vata_pct", 30), "unit": "%"}},
                {"code": {"text": "Pitta Percentage"}, "valueQuantity": {"value": prakriti.get("pitta_pct", 50), "unit": "%"}},
                {"code": {"text": "Kapha Percentage"}, "valueQuantity": {"value": prakriti.get("kapha_pct", 20), "unit": "%"}}
            ]
        }
    }
    entries.append(obs_prakriti)

    # 4. MedicationRequests
    for idx, med in enumerate(prescriptions):
        m_id = f"med-req-{session_id}-{idx}"
        entries.append({
            "fullUrl": f"urn:uuid:{m_id}",
            "resource": {
                "resourceType": "MedicationRequest",
                "id": m_id,
                "status": "active",
                "intent": "order",
                "medicationCodeableConcept": {
                    "text": med.get("name"),
                    "coding": [{"system": "http://ayush.gov.in/namaste" if med.get("category") == "Ayurvedic" else "http://hl7.org/fhir/sid/rxnorm", "display": med.get("name")}]
                },
                "subject": {"reference": f"urn:uuid:{patient_id}"},
                "dosageInstruction": [{"text": med.get("dosage", "As advised by Physician")}]
            }
        })

    return {
        "resourceType": "Bundle",
        "id": bundle_id,
        "meta": {
            "versionId": "1",
            "lastUpdated": datetime.now(timezone.utc).isoformat(),
            "security": [
                {
                    "system": "https://abdm.gov.in/security/audit-hash",
                    "code": audit_hash,
                    "display": "SHA-256 Medico-Legal Audit Trail"
                }
            ]
        },
        "identifier": {
            "system": "https://abdm.gov.in/fhir/bundles",
            "value": bundle_id
        },
        "type": "document",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total": len(entries),
        "entry": entries
    }
