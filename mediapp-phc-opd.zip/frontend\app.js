
/**
 * MediKiosk Web Application Prototype - Frontend Controller
 * Team HACKERS - Smart India Hackathon (Ministry of Ayush)
 */

// Global State
let currentMode = 'kiosk';
let currentLang = 'en';
let currentKioskStep = 1;
let activePatientSessionId = 'KIOSK-BLR-001';
let isRecordingVoice = false;
let recognition = null;

let kioskAnswers = {
  body_frame: 'pitta',
  skin_nature: 'pitta',
  appetite_agni: 'pitta',
  weather_thermal: 'pitta',
  sleep_pattern: 'vata',
  stress_mind: 'pitta'
};

let activeSymptoms = [
  'Burning in chest / Acid reflux (Amlapitta)',
  'Occasional loose stools (Atisara)'
];

let activeDoctorRx = [
  { name: 'Kamadudha Ras (Moti Yukta)', dosage: '1 tab BD after meals', category: 'Ayurvedic' },
  { name: 'Avipattikar Churna', dosage: '3g twice daily before food', category: 'Ayurvedic' }
];

let acknowledgedAlerts = [];
let cachedFhirBundle = null;

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', () => {
  initSpeechRecognition();
  renderPrakritiQuestions();
  updateLivePrakriti();
  loadOpdQueue();
  selectPatient('KIOSK-BLR-001');
});

// ==================== MODE & LANGUAGE SWITCHING ====================
function switchMode(mode) {
  currentMode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active'));

  if (mode === 'kiosk') {
    document.getElementById('btn-kiosk-mode').classList.add('active');
    document.getElementById('view-kiosk').classList.add('active');
  } else {
    document.getElementById('btn-doctor-mode').classList.add('active');
    document.getElementById('view-doctor').classList.add('active');
    loadOpdQueue();
    checkAlertsLive();
  }
}

function setLanguage(lang) {
  currentLang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`lang-${lang}`).classList.add('active');

  if (lang === 'hi') {
    showToast('हिन्दी भाषा सक्षम की गई (Bhashini Engine Ready)');
    speakText('नमस्ते, मेडीकियोस्क में आपका स्वागत है। कृपया अपनी स्वास्थ्य जानकारी दर्ज करें।', 'hi-IN');
  } else {
    showToast('English Language Enabled');
    speakText('Welcome to MediKiosk. Please register to begin your pre-consultation intake.', 'en-US');
  }
}

// ==================== KIOSK STEPPER CONTROLLER ====================
function goToKioskStep(stepNum) {
  currentKioskStep = stepNum;

  // Update step nodes
  for (let i = 1; i <= 5; i++) {
    const node = document.getElementById(`step-node-${i}`);
    node.classList.remove('active', 'completed');
    if (i < stepNum) node.classList.add('completed');
    if (i === stepNum) node.classList.add('active');

    const content = document.getElementById(`kiosk-step-${i}`);
    if (content) {
      if (i === stepNum) {
        content.classList.remove('hidden');
      } else {
        content.classList.add('hidden');
      }
    }
  }

  // Spoken voice guidance simulating Bhashini
  if (stepNum === 2) {
    if (currentLang === 'hi') {
      speakText('कृपया अपने मुख्य लक्षण बोलें या स्क्रीन पर स्पर्श करके चुनें।', 'hi-IN');
    } else {
      speakText('Please speak your chief complaints or tap on the symptom chips.', 'en-US');
    }
  } else if (stepNum === 3) {
    if (currentLang === 'hi') {
      speakText('अब आपकी प्रकृति और अग्नि की आयुर्वेदिक जांच की जाएगी।', 'hi-IN');
    } else {
      speakText('Beginning your Ayurvedic Prakriti and Agni assessment.', 'en-US');
    }
  }
}

// ==================== PATIENT PRESETS (DIVERSE CLINICAL CASES) ====================
function loadPatientPreset(preset) {
  if (preset === 'rajesh') {
    document.getElementById('kiosk-name').value = 'Rajesh Kumar';
    document.getElementById('kiosk-age').value = '45';
    document.getElementById('kiosk-gender').value = 'Male';
    document.getElementById('kiosk-abha').value = '91-4829-1848-2916';
    document.getElementById('kiosk-phone').value = '+91 91482 91848';
    document.getElementById('display-abha-name').innerText = 'Rajesh Kumar';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-4829-1848-2916';
    document.getElementById('display-abha-addr').innerText = 'rajesh.kumar45@abdm';

    document.getElementById('vital-bp').value = '90/60';
    document.getElementById('vital-pulse').value = '108';
    document.getElementById('vital-spo2').value = '94';
    document.getElementById('vital-temp').value = '104.2';

    activeSymptoms = ['High Fever & Rigors (104.2°F)', 'Severe Shaking Chills', 'Hypotension (90/60)', 'Dark Urine'];
    document.getElementById('voice-transcript').innerText = '"नमस्ते डॉक्टर साहब, मुझे ३ दिन से बहुत तेज़ ठंड लगकर बुखार आ रहा है और पेशाब का रंग गहरा है।"';
    showToast('🚨 Loaded Preset: Rajesh Kumar (Acute Malaria, Chills, Sulfa Allergy)');
  }
  else if (preset === 'vikas') {
    document.getElementById('kiosk-name').value = 'Vikas Patil';
    document.getElementById('kiosk-age').value = '36';
    document.getElementById('kiosk-gender').value = 'Male';
    document.getElementById('kiosk-abha').value = '91-5542-8819-2041';
    document.getElementById('kiosk-phone').value = '+91 98221 55643';
    document.getElementById('display-abha-name').innerText = 'Vikas Patil';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-5542-8819-2041';
    document.getElementById('display-abha-addr').innerText = 'vikas.patil@abdm';

    document.getElementById('vital-bp').value = '100/68';
    document.getElementById('vital-pulse').value = '102';
    document.getElementById('vital-spo2').value = '97';
    document.getElementById('vital-temp').value = '103.5';

    activeSymptoms = ['Continuous High Fever (103.5°F)', 'Retro-Orbital Eye Pain', 'Breakbone Bodyaches', 'Petechial Rash'];
    document.getElementById('voice-transcript').innerText = '"डॉक्टर साहब, ४ दिन से आंखों के पीछे असहनीय दर्द और हड्डी-तोड़ बुखार है। बांहों पर लाल चकत्ते आ रहे हैं।"';
    showToast('🚨 Loaded Preset: Vikas Patil (Dengue Suspect, Breakbone Fever)');
  }
  else if (preset === 'sunita') {
    document.getElementById('kiosk-name').value = 'Sunita Devi';
    document.getElementById('kiosk-age').value = '52';
    document.getElementById('kiosk-gender').value = 'Female';
    document.getElementById('kiosk-abha').value = '91-7782-9901-4412';
    document.getElementById('kiosk-phone').value = '+91 94411 22334';
    document.getElementById('display-abha-name').innerText = 'Sunita Devi';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-7782-9901-4412';
    document.getElementById('display-abha-addr').innerText = 'sunita.devi@abdm';

    document.getElementById('vital-bp').value = '138/88';
    document.getElementById('vital-pulse').value = '112';
    document.getElementById('vital-spo2').value = '89';
    document.getElementById('vital-temp').value = '99.1';

    activeSymptoms = ['Acute Breathlessness (Dyspnea)', 'Loud Expiratory Wheezing', 'Chest Tightness', 'SpO2 89% Hypoxemia'];
    document.getElementById('voice-transcript').innerText = '"रात से सांस बहुत फूल रही है, छाती में सीटी जैसी आवाज़ आ रही है और ऑक्सीजन ८९% हो गई है।"';
    showToast('🚨 Loaded Preset: Sunita Devi (Acute Asthma, Wheezing, SpO2 89%)');
  }
  else if (preset === 'sita') {
    document.getElementById('kiosk-name').value = 'Sita Bai';
    document.getElementById('kiosk-age').value = '29';
    document.getElementById('kiosk-gender').value = 'Female';
    document.getElementById('kiosk-abha').value = '91-2831-7721-9041';
    document.getElementById('kiosk-phone').value = '+91 98231 44512';
    document.getElementById('display-abha-name').innerText = 'Sita Bai';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-2831-7721-9041';
    document.getElementById('display-abha-addr').innerText = 'sitabai.anc@abdm';

    document.getElementById('vital-bp').value = '160/105';
    document.getElementById('vital-pulse').value = '92';
    document.getElementById('vital-spo2').value = '98';
    document.getElementById('vital-temp').value = '98.8';

    activeSymptoms = ['Severe Frontal Headache', 'High BP (160/105)', 'Pedal Edema +3', 'Epigastric Pain', '34w Pregnancy'];
    document.getElementById('voice-transcript').innerText = '"सीता बाई ३४ हफ्ते की गर्भवती हैं। पिछले दो दिनों से सिर में बहुत दर्द और पैरों में सूजन है, बीपी १६०/१०५ आया है।"';
    showToast('🚨 Loaded Preset: Sita Bai (34w Antenatal Pre-eclampsia, BP 160/105)');
  }
  else if (preset === 'kavita') {
    document.getElementById('kiosk-name').value = 'Kavita Meena';
    document.getElementById('kiosk-age').value = '24';
    document.getElementById('kiosk-gender').value = 'Female';
    document.getElementById('kiosk-abha').value = '91-6621-3304-9812';
    document.getElementById('kiosk-phone').value = '+91 97654 33211';
    document.getElementById('display-abha-name').innerText = 'Kavita Meena';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-6621-3304-9812';
    document.getElementById('display-abha-addr').innerText = 'kavita.meena@abdm';

    document.getElementById('vital-bp').value = '98/66';
    document.getElementById('vital-pulse').value = '104';
    document.getElementById('vital-spo2').value = '98';
    document.getElementById('vital-temp').value = '100.2';

    activeSymptoms = ['Profuse Watery Diarrhea (8 episodes)', 'Abdominal Colic', 'Sunken Eyes & Dehydration', 'Dry Mouth'];
    document.getElementById('voice-transcript').innerText = '"आज सुबह से ८ बार पानी जैसे दस्त और उल्टी हुई है। आंखें धंस गई हैं और बहुत चक्कर आ रहा है।"';
    showToast('⚠️ Loaded Preset: Kavita Meena (Acute Gastroenteritis, Dehydration)');
  }
  else if (preset === 'ramesh') {
    document.getElementById('kiosk-name').value = 'Rameshwar Prasad';
    document.getElementById('kiosk-age').value = '58';
    document.getElementById('kiosk-gender').value = 'Male';
    document.getElementById('kiosk-abha').value = '91-4521-8890-1123';
    document.getElementById('kiosk-phone').value = '+91 98765 43210';
    document.getElementById('display-abha-name').innerText = 'Rameshwar Prasad';
    document.getElementById('display-abha-id').innerText = 'ABHA: 91-4521-8890-1123';
    document.getElementById('display-abha-addr').innerText = 'rameshwar52@abdm';

    document.getElementById('vital-bp').value = '138/88';
    document.getElementById('vital-pulse').value = '82';
    document.getElementById('vital-spo2').value = '97';
    document.getElementById('vital-temp').value = '98.4';

    activeSymptoms = ['Burning in chest / Acid reflux (Amlapitta)', 'Epigastric Heartburn', 'Sour Regurgitation'];
    document.getElementById('voice-transcript').innerText = '"मुझे पिछले एक महीने से सीने में बहुत तेज़ जलन होती है और खट्टी डकारें आती हैं।"';
    showToast('📋 Loaded Preset: Rameshwar Prasad (GERD, Acid Reflux)');
  }
}

// ==================== MULTIMODAL VOICE ASSISTANT (BHASHINI SIMULATOR) ====================
function initSpeechRecognition() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRec) {
    recognition = new SpeechRec();
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      isRecordingVoice = true;
      document.getElementById('btn-mic').classList.add('recording');
      document.getElementById('voice-waves').classList.add('active');
      document.getElementById('voice-status').innerText = currentLang === 'hi' ? 'सुन रहा हूँ... (Bhashini Listening in Hindi)' : 'Listening in English (Bhashini ASR)...';
    };

    recognition.onresult = (event) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        transcript += event.results[i][0].transcript;
      }
      document.getElementById('voice-transcript').innerText = `"${transcript}"`;
    };

    recognition.onend = () => {
      isRecordingVoice = false;
      document.getElementById('btn-mic').classList.remove('recording');
      document.getElementById('voice-waves').classList.remove('active');
      document.getElementById('voice-status').innerText = 'Voice captured! Tap mic to record again.';
      showToast('Speech recognized and transcribed via Bhashini pipeline');
    };

    recognition.onerror = () => {
      isRecordingVoice = false;
      document.getElementById('btn-mic').classList.remove('recording');
      document.getElementById('voice-waves').classList.remove('active');
      document.getElementById('voice-status').innerText = 'Voice intake completed (Demo mode ready)';
    };
  }
}

function toggleVoiceRecording() {
  if (!recognition) {
    // Simulated speech wave and text
    isRecordingVoice = !isRecordingVoice;
    const btn = document.getElementById('btn-mic');
    const waves = document.getElementById('voice-waves');
    const status = document.getElementById('voice-status');
    const transcript = document.getElementById('voice-transcript');

    if (isRecordingVoice) {
      btn.classList.add('recording');
      waves.classList.add('active');
      status.innerText = 'Listening via Bhashini Regional ASR...';
      setTimeout(() => {
        btn.classList.remove('recording');
        waves.classList.remove('active');
        status.innerText = 'Audio synthesized into clinical tokens.';
        if (currentLang === 'hi') {
          transcript.innerText = '"सीने में बहुत जलन और खट्टी डकारें आ रही हैं, 4 हफ्ते से परेशानी है।"';
          speakText('आपके लक्षण दर्ज कर लिए गए हैं: अम्लपित्त और सीने में जलन।', 'hi-IN');
        } else {
          transcript.innerText = '"Severe burning in chest and sour belching since 4 weeks."';
          speakText('Your symptoms have been recorded: Acid reflux and epigastric discomfort.', 'en-US');
        }
        isRecordingVoice = false;
      }, 2500);
    }
    return;
  }

  if (isRecordingVoice) {
    recognition.stop();
  } else {
    recognition.lang = currentLang === 'hi' ? 'hi-IN' : 'en-US';
    try {
      recognition.start();
    } catch (e) {
      console.warn('Recognition already active');
    }
  }
}

function speakText(text, lang) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang || (currentLang === 'hi' ? 'hi-IN' : 'en-US');
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
  }
}

function toggleSymptomChip(chip, symptomName) {
  chip.classList.toggle('active');
  if (chip.classList.contains('active')) {
    if (!activeSymptoms.includes(symptomName)) activeSymptoms.push(symptomName);
  } else {
    activeSymptoms = activeSymptoms.filter(s => s !== symptomName);
  }
}

function updatePainLevel(val) {
  document.getElementById('pain-level-val').innerText = `${val} / 10`;
  const label = document.getElementById('pain-desc-label');
  if (val <= 3) {
    label.innerText = 'Mild (अल्प)';
    label.style.color = '#10b981';
  } else if (val <= 6) {
    label.innerText = 'Moderate (मध्यम)';
    label.style.color = '#f59e0b';
  } else if (val <= 8) {
    label.innerText = 'Moderate-Severe (तीव्र)';
    label.style.color = '#f97316';
  } else {
    label.innerText = 'Critical Red-Flag (आपातकालीन)';
    label.style.color = '#ef4444';
  }
}

// ==================== AYUSH PRAKRITI ENGINE ====================
const PRAKRITI_DATA = [
  {
    id: "body_frame",
    question: "Body Frame & Physical Build / शारीरिक बनावट",
    options: {
      vata: "Lean, thin, tall/short, difficulty gaining weight (दुबला-पतला)",
      pitta: "Medium, athletic, well-proportioned (मध्यम, सुडौल)",
      kapha: "Broad, heavy, stocky, easily gains weight (मजबूत, भारी)"
    }
  },
  {
    id: "skin_nature",
    question: "Skin Texture & Nature / त्वचा की प्रकृति",
    options: {
      vata: "Dry, rough, thin, cool, chapped (रूखी, खुरदरी)",
      pitta: "Warm, reddish/fair, sensitive, prone to acne (उष्ण, तिल/मुंहासे)",
      kapha: "Smooth, oily, thick, moist, glowing (चिकनी, तैलीय, कोमल)"
    }
  },
  {
    id: "appetite_agni",
    question: "Appetite & Digestion (Agni) / भूख और पाचन (अग्नि)",
    options: {
      vata: "Variable, irregular, frequent bloating (विषमाग्नि - अनियमित)",
      pitta: "Sharp, intense hunger, burning sensation/acidity (तीक्ष्णाग्नि - तेज भूख, जलन)",
      kapha: "Slow, steady appetite, heavy feeling after meal (मंदाग्नि - सुस्त, भारीपन)"
    }
  },
  {
    id: "weather_thermal",
    question: "Temperature Tolerance / मौसम सहनशीलता",
    options: {
      vata: "Dislikes cold & wind, loves sunlight and heat (ठंड असहनीय)",
      pitta: "Dislikes heat & sun, sweats easily, loves cool breeze (गर्मी असहनीय)",
      kapha: "Dislikes damp/wet cold, comfortable in dry warmth (नम ठंड असहनीय)"
    }
  },
  {
    id: "sleep_pattern",
    question: "Sleep Quality / नींद की स्थिति",
    options: {
      vata: "Light, interrupted, easily woken, dreams of movement (हल्की, बेचैन नींद)",
      pitta: "Moderate sound sleep (6-7 hrs), wake up refreshed (मध्यम नींद)",
      kapha: "Deep, heavy sleep (8+ hrs), difficulty waking up (गहरी, भारी नींद)"
    }
  },
  {
    id: "stress_mind",
    question: "Mental Temperament & Stress / मानसिक स्वभाव और तनाव",
    options: {
      vata: "Quick to worry, anxious, restless overthinker (चिंतित, चंचल)",
      pitta: "Ambitious, short-tempered, irritable, sharp intellect (तीक्ष्ण, क्रोधी)",
      kapha: "Calm, patient, steady, slow to anger, loyal (शांत, धैर्यवान)"
    }
  }
];

function renderPrakritiQuestions() {
  const container = document.getElementById('prakriti-questions-container');
  container.innerHTML = '';

  PRAKRITI_DATA.forEach((q, idx) => {
    const card = document.createElement('div');
    card.className = 'prakriti-q-card';

    let optionsHtml = '';
    for (const [doshaKey, text] of Object.entries(q.options)) {
      const isSelected = kioskAnswers[q.id] === doshaKey;
      optionsHtml += `
        <div class="p-option-label ${isSelected ? 'selected' : ''}" onclick="selectPrakritiOption('${q.id}', '${doshaKey}')">
          <input type="radio" name="${q.id}" value="${doshaKey}" ${isSelected ? 'checked' : ''} style="margin-top: 3px;" />
          <span>${text}</span>
        </div>
      `;
    }

    card.innerHTML = `
      <div class="p-q-title">${idx + 1}. ${q.question}</div>
      <div class="p-options-group">${optionsHtml}</div>
    `;
    container.appendChild(card);
  });
}

function selectPrakritiOption(qId, doshaKey) {
  kioskAnswers[qId] = doshaKey;
  renderPrakritiQuestions();
  updateLivePrakriti();
}

function updateLivePrakriti() {
  let v = 0, p = 0, k = 0;
  let total = 0;
  for (const dosha of Object.values(kioskAnswers)) {
    if (dosha === 'vata') v++;
    if (dosha === 'pitta') p++;
    if (dosha === 'kapha') k++;
    total++;
  }

  const vPct = Math.round((v / total) * 100);
  const pPct = Math.round((p / total) * 100);
  const kPct = Math.round((k / total) * 100);

  // Update text & meter bars
  document.getElementById('meter-val-vata').innerText = `${vPct}%`;
  document.getElementById('meter-val-pitta').innerText = `${pPct}%`;
  document.getElementById('meter-val-kapha').innerText = `${kPct}%`;

  document.getElementById('fill-vata').style.width = `${vPct}%`;
  document.getElementById('fill-pitta').style.width = `${pPct}%`;
  document.getElementById('fill-kapha').style.width = `${kPct}%`;

  // Circumference = 2 * PI * 38 = ~238.7
  const circ = 238.7;
  const vDash = (vPct / 100) * circ;
  const pDash = (pPct / 100) * circ;
  const kDash = (kPct / 100) * circ;

  document.getElementById('ring-vata').setAttribute('stroke-dasharray', `${vDash} ${circ}`);
  document.getElementById('ring-vata').setAttribute('stroke-dashoffset', '0');

  document.getElementById('ring-pitta').setAttribute('stroke-dasharray', `${pDash} ${circ}`);
  document.getElementById('ring-pitta').setAttribute('stroke-dashoffset', `-${vDash}`);

  document.getElementById('ring-kapha').setAttribute('stroke-dasharray', `${kDash} ${circ}`);
  document.getElementById('ring-kapha').setAttribute('stroke-dashoffset', `-${vDash + pDash}`);

  let dominant = 'Pitta';
  if (vPct >= pPct && vPct >= kPct) dominant = 'Vata';
  else if (kPct >= vPct && kPct >= pPct) dominant = 'Kapha';

  document.getElementById('live-dominant-dosha').innerText = dominant;

  // Dashavidha Agni update
  const agniDisp = document.getElementById('disp-agni');
  if (kioskAnswers['appetite_agni'] === 'pitta') agniDisp.innerText = 'Tikshnagni (तीक्ष्णाग्नि)';
  else if (kioskAnswers['appetite_agni'] === 'vata') agniDisp.innerText = 'Vishamagni (विषमाग्नि)';
  else agniDisp.innerText = 'Mandagni (मंदाग्नि)';
}

// ==================== DOCUMENT OCR SCANNER ====================
function runDocumentScanAnimation() {
  const laser = document.getElementById('laser-line');
  const triggerBtn = document.getElementById('btn-scan-trigger');
  const statusHint = document.getElementById('ocr-status-hint');

  laser.classList.add('scanning');
  triggerBtn.disabled = true;
  triggerBtn.innerText = '🔍 Scanning Document via PaddleOCR...';
  statusHint.innerText = 'Extracting handwritten clinical entities & RxNorm/NAMASTE mappings...';

  setTimeout(() => {
    laser.classList.remove('scanning');
    triggerBtn.disabled = false;
    triggerBtn.innerText = '✓ Digitization Complete (Re-run)';
    statusHint.innerText = 'Extracted 3 active medications and 2 clinical conditions.';
    showToast('Document Digitized! Mapped to ABDM baseline.');
  }, 2200);
}

// ==================== SUBMIT KIOSK CASE ====================
async function submitKioskCase() {
  const patientName = document.getElementById('kiosk-name').value;
  const patientAge = parseInt(document.getElementById('kiosk-age').value) || 50;
  const patientGender = document.getElementById('kiosk-gender').value;
  const patientAbha = document.getElementById('kiosk-abha').value;
  const patientPhone = document.getElementById('kiosk-phone').value;

  const payload = {
    name: patientName,
    age: patientAge,
    gender: patientGender,
    phone: patientPhone,
    abha_id: patientAbha,
    preferred_lang: currentLang,
    vitals: {
      bp: document.getElementById('vital-bp').value,
      pulse: parseInt(document.getElementById('vital-pulse').value) || 78,
      spo2: parseInt(document.getElementById('vital-spo2').value) || 98,
      temp: document.getElementById('vital-temp').value
    },
    chief_complaints: activeSymptoms.map(s => ({ symptom: s, duration: "3 weeks", severity: 7 })),
    known_allergies: ["Sulfa drugs"],
    chronic_conditions: ["Type 2 Diabetes Mellitus", "Dyslipidemia"],
    prakriti_answers: kioskAnswers,
    dashavidha: {
      agni: document.getElementById('disp-agni').innerText,
      bala: "Madhyama (Moderate)",
      desha: "Anupa (Humid)",
      satmya: "Katu-Amla (Spicy/Sour)"
    },
    ocr_extracted_meds: ["Metformin 500mg BD", "Atorvastatin 20mg OD", "Pantoprazole 40mg"]
  };

  try {
    const res = await fetch('/api/v1/intake/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    // Populate Ticket Screen
    document.getElementById('ticket-patient-name').innerText = patientName;
    document.getElementById('ticket-patient-meta').innerText = `${patientAge} / ${patientGender}`;
    document.getElementById('ticket-patient-abha').innerText = patientAbha;
    document.getElementById('ticket-patient-prakriti').innerText = `${data.prakriti.primary_dosha} Dominant`;
    document.getElementById('ticket-token-no').innerText = `#0${Math.floor(Math.random() * 5) + 3}`;

    goToKioskStep(5);
    showToast('Case successfully pushed to OPD Doctor Queue!');
    loadOpdQueue();
  } catch (e) {
    console.error('Submission error:', e);
    // Offline / Mock fallback
    document.getElementById('ticket-patient-name').innerText = patientName;
    document.getElementById('ticket-patient-meta').innerText = `${patientAge} / ${patientGender}`;
    document.getElementById('ticket-patient-abha').innerText = patientAbha;
    document.getElementById('ticket-patient-prakriti').innerText = 'Pitta Dominant';
    goToKioskStep(5);
  }
}

// ==================== DOCTOR OPD PORTAL CONTROLLER ====================
async function loadOpdQueue() {
  try {
    const res = await fetch('/api/v1/queue');
    const data = await res.json();
    const container = document.getElementById('queue-list-container');
    container.innerHTML = '';

    document.getElementById('sidebar-queue-badge').innerText = `${data.total_waiting} Waiting`;
    document.getElementById('header-queue-count').innerText = data.total_waiting;

    data.queue.forEach((pat, idx) => {
      const card = document.createElement('div');
      card.className = `queue-item-card ${pat.session_id === activePatientSessionId ? 'active' : ''}`;
      card.onclick = () => selectPatient(pat.session_id);

      const doshaClass = pat.primary_dosha.toLowerCase().includes('vata') ? 'vata' : 'pitta';

      card.innerHTML = `
        <div class="queue-card-top">
          <span class="queue-card-name">${pat.name}</span>
          <span class="queue-token-pill">#0${idx + 1}</span>
        </div>
        <div class="queue-card-meta">${pat.age}y • ${pat.gender} • ${pat.chief_complaint}</div>
        <div class="queue-card-tags">
          <span class="mini-prakriti-tag ${doshaClass}">${pat.primary_dosha}</span>
          <span class="status-badge ${pat.status.toLowerCase()}">${pat.status}</span>
        </div>
      `;
      container.appendChild(card);
    });
  } catch (e) {
    console.warn('Backend queue fetch failed, using pre-seeded queue');
  }
}

async function selectPatient(sessionId) {
  activePatientSessionId = sessionId;
  document.querySelectorAll('.queue-item-card').forEach(c => c.classList.remove('active'));

  try {
    const res = await fetch(`/api/v1/patient/${sessionId}`);
    const p = await res.json();

    // Populate Banner
    document.getElementById('doc-patient-name').innerText = p.patient.name;
    document.getElementById('doc-patient-meta').innerText = `${p.patient.age} Yrs • ${p.patient.gender} • ${p.patient.preferred_lang}`;
    document.getElementById('doc-patient-abha').innerText = `ABHA: ${p.patient.abha_id}`;
    document.getElementById('doc-patient-phone').innerText = p.patient.phone;
    document.getElementById('doc-patient-status').innerText = p.status;

    // Vitals
    document.getElementById('doc-v-bp').innerText = p.allopathic_triage.vitals.bp;
    document.getElementById('doc-v-pulse').innerText = `${p.allopathic_triage.vitals.pulse} bpm`;
    document.getElementById('doc-v-spo2').innerText = `${p.allopathic_triage.vitals.spo2}%`;
    document.getElementById('doc-v-temp').innerText = `${p.allopathic_triage.vitals.temp} °F`;

    // Complaints
    const compList = document.getElementById('doc-complaints-list');
    compList.innerHTML = '';
    p.allopathic_triage.chief_complaints.forEach(c => {
      const li = document.createElement('li');
      li.innerText = `${c.symptom} (${c.duration}, Severity: ${c.severity}/10)`;
      compList.appendChild(li);
    });

    // Past Meds
    const medsContainer = document.getElementById('doc-past-meds-list');
    medsContainer.innerHTML = '';
    p.digitized_ocr_baseline.extracted_past_medications.forEach(m => {
      const span = document.createElement('span');
      span.className = 'chip-med';
      span.innerText = m;
      medsContainer.appendChild(span);
    });

    // Prakriti
    const pr = p.ayush_assessment.prakriti;
    document.getElementById('doc-constitution-badge').innerText = pr.constitution_type;
    document.getElementById('doc-v-vata').innerText = `${pr.vata_pct}%`;
    document.getElementById('doc-v-pitta').innerText = `${pr.pitta_pct}%`;
    document.getElementById('doc-v-kapha').innerText = `${pr.kapha_pct}%`;
    document.getElementById('doc-bar-vata').style.width = `${pr.vata_pct}%`;
    document.getElementById('doc-bar-pitta').style.width = `${pr.pitta_pct}%`;
    document.getElementById('doc-bar-kapha').style.width = `${pr.kapha_pct}%`;

    // Dashavidha
    const d = p.ayush_assessment.dashavidha;
    document.getElementById('doc-d-agni').innerText = d.agni;
    document.getElementById('doc-d-bala').innerText = d.bala;
    document.getElementById('doc-d-desha').innerText = d.desha;
    document.getElementById('doc-d-satmya').innerText = d.satmya;

    renderRxTable();
    checkAlertsLive();
  } catch (e) {
    console.error('Error fetching patient dossier', e);
  }
}

// ==================== PRESCRIPTION BUILDER & SAFETY ALERTS (USP 1) ====================
function renderRxTable() {
  const tbody = document.getElementById('rx-table-body');
  tbody.innerHTML = '';

  activeDoctorRx.forEach((item, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="badge-med-type ${item.category === 'Ayurvedic' ? 'ayur' : 'allo'}">${item.category}</span></td>
      <td><strong>${item.name}</strong></td>
      <td>${item.dosage}</td>
      <td>
        <button class="btn-remove-row" onclick="removeMedicineFromRx(${idx})">✕</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function addMedicineToRx(name, dosage, category) {
  // Avoid duplicate entries
  if (activeDoctorRx.some(m => m.name.toLowerCase() === name.toLowerCase())) {
    showToast(`${name} is already in the prescription`);
    return;
  }
  activeDoctorRx.push({ name, dosage, category });
  renderRxTable();
  checkAlertsLive();
  showToast(`Added ${name} to Rx Pad`);
}

function removeMedicineFromRx(idx) {
  const removed = activeDoctorRx[idx];
  activeDoctorRx.splice(idx, 1);
  renderRxTable();
  checkAlertsLive();
  showToast(`Removed ${removed.name}`);
}

async function checkAlertsLive() {
  const alertsBox = document.getElementById('clinical-alerts-box');

  try {
    const res = await fetch('/api/v1/consultation/check-alerts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: activePatientSessionId,
        prescriptions: activeDoctorRx
      })
    });
    const data = await res.json();
    renderClinicalAlerts(data.alerts);
  } catch (e) {
    console.warn('Using client-side clinical interaction fallback');
    renderClientSideAlerts();
  }
}

function renderClinicalAlerts(alerts) {
  const alertsBox = document.getElementById('clinical-alerts-box');
  alertsBox.innerHTML = '';

  if (!alerts || alerts.length === 0) {
    alertsBox.innerHTML = `
      <div style="font-size: 0.82rem; color: #10b981; padding: 0.6rem; background: rgba(16, 185, 129, 0.1); border-radius: 8px; border: 1px dashed rgba(16, 185, 129, 0.4);">
        ✓ No herb-drug interactions or contraindications detected with active patient history.
      </div>
    `;
    return;
  }

  alerts.forEach(alert => {
    const isCritical = alert.severity.toLowerCase() === 'critical' || alert.severity.toLowerCase() === 'high';
    const isAcked = acknowledgedAlerts.includes(alert.rule_id);

    const card = document.createElement('div');
    card.className = `soft-warning-card ${isCritical ? 'critical' : ''}`;
    card.innerHTML = `
      <div class="alert-top-row">
        <div class="alert-heading">
          <span>⚠️</span>
          <span>${alert.title}</span>
        </div>
        <span class="severity-pill ${alert.severity.toLowerCase()}">${alert.severity} Soft Warning</span>
      </div>
      <div class="alert-rationale">
        <strong>Mechanism:</strong> ${alert.rationale}
        <br><strong style="color: #fbbf24;">Clinical Risk:</strong> ${alert.clinical_risk}
      </div>
      <div class="alert-recommendation">
        <strong>AI Recommendation:</strong> ${alert.recommendation}
      </div>
      <div class="alert-action-row">
        <span class="autonomy-note">Physician decision support • Doctor retains ultimate authority</span>
        <button class="btn-ack-alert ${isAcked ? 'acknowledged' : ''}" onclick="acknowledgeAlert('${alert.rule_id}', this)">
          ${isAcked ? '✓ Acknowledged by Physician' : 'Acknowledge & Proceed'}
        </button>
      </div>
    `;
    alertsBox.appendChild(card);
  });
}

function renderClientSideAlerts() {
  const rxNames = activeDoctorRx.map(m => m.name.toLowerCase());
  const alerts = [];

  if (rxNames.some(n => n.includes('guggulu'))) {
    alerts.push({
      rule_id: 'RULE-GUGGULU-STATIN',
      severity: 'High',
      title: 'Guggulu + Statin CYP3A4 Interaction',
      rationale: 'Patient is actively taking Atorvastatin 20mg. Guggulsterones alter CYP3A4 metabolism and statin clearance.',
      clinical_risk: 'Elevated risk of statin-induced myopathy and severe muscle aches.',
      recommendation: 'Advise 4+ hour spacing, review statin dosage, or monitor serum CK.'
    });
  }

  if (rxNames.some(n => n.includes('avipattikar'))) {
    alerts.push({
      rule_id: 'RULE-AVIPATTIKAR-DIARRHEA',
      severity: 'Critical',
      title: 'Purgative Herb Contraindication in Active Diarrhea',
      rationale: 'Patient presented with occasional loose stools (Atisara). Avipattikar contains ~44% Trivrit (Operculina turpethum), an active purgative.',
      clinical_risk: 'Exacerbation of fluid loss, abdominal cramps, and dehydration.',
      recommendation: 'Switch to mild Pitta shamaka: Praval Pishti or Kamadudha Ras.'
    });
  }

  if (rxNames.some(n => n.includes('ashwagandha'))) {
    alerts.push({
      rule_id: 'RULE-ASHWAGANDHA-METFORMIN',
      severity: 'Moderate',
      title: 'Additive Hypoglycemic Effect with Metformin',
      rationale: 'Ashwagandha stimulates beta-cell insulin secretion, synergizing with existing Metformin.',
      clinical_risk: 'Potential for acute episodes of symptomatic hypoglycemia.',
      recommendation: 'Advise daily capillary blood glucose monitoring.'
    });
  }

  renderClinicalAlerts(alerts);
}

function acknowledgeAlert(ruleId, btn) {
  if (!acknowledgedAlerts.includes(ruleId)) acknowledgedAlerts.push(ruleId);
  btn.classList.add('acknowledged');
  btn.innerText = '✓ Acknowledged by Physician';
  showToast('Soft warning acknowledged. Doctor retains final authority.');
}

// ==================== MEDICO-LEGAL AUDIT TRAIL (USP 2) ====================
async function finalizePrescription() {
  const diagnosis = document.getElementById('doc-input-diagnosis').value;
  const notes = document.getElementById('doc-input-notes').value;

  const payload = {
    session_id: activePatientSessionId,
    doctor_id: "DOC-AYU-8821",
    doctor_name: "Dr. Vikram Sharma, MD (Ayurveda)",
    provisional_diagnosis: diagnosis,
    doctor_notes: notes,
    prescriptions: activeDoctorRx,
    acknowledged_alerts: acknowledgedAlerts
  };

  try {
    const res = await fetch('/api/v1/consultation/finalize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    // Update UI Status
    const auditBadge = document.getElementById('audit-status-badge');
    auditBadge.classList.add('signed');
    auditBadge.innerHTML = `
      <span class="audit-icon">🛡️</span>
      <span>Tamper-Proof SHA-256 Hash: <code style="color: #5eead4;">${data.audit_fingerprint.substring(0, 16)}...</code></span>
    `;

    document.getElementById('doc-patient-status').innerText = 'Completed';
    document.getElementById('doc-patient-status').className = 'status-badge completed';

    // Open Audit Certificate Modal
    document.getElementById('cert-hash-val').innerText = data.audit_fingerprint;
    document.getElementById('cert-abha-id').innerText = document.getElementById('doc-patient-abha').innerText.replace('ABHA: ', '');
    document.getElementById('cert-time').innerText = new Date().toUTCString();

    const auditModal = document.getElementById('modal-audit');
    if (auditModal.showModal) auditModal.showModal();

    showToast('Prescription sealed with SHA-256 audit fingerprint!');
    loadOpdQueue();
  } catch (e) {
    console.error('Finalize error', e);
    // Offline fallback
    const fallbackHash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    document.getElementById('cert-hash-val').innerText = fallbackHash;
    const auditModal = document.getElementById('modal-audit');
    if (auditModal.showModal) auditModal.showModal();
  }
}

function closeAuditModal() {
  const auditModal = document.getElementById('modal-audit');
  if (auditModal.close) auditModal.close();
}

// ==================== ABDM FHIR R4 BUNDLE & DOCTOR SHIFTING (USP 3) ====================
async function openFhirModal() {
  const modal = document.getElementById('modal-fhir');
  const viewer = document.getElementById('fhir-json-display');
  viewer.innerText = 'Fetching HL7 FHIR R4 standard JSON from ABDM gateway...';

  if (modal.showModal) modal.showModal();

  try {
    const res = await fetch(`/api/v1/fhir/${activePatientSessionId}`);
    const bundle = await res.json();
    cachedFhirBundle = bundle;
    viewer.innerText = JSON.stringify(bundle, null, 2);
  } catch (e) {
    console.warn('FHIR fetch error, rendering standard sample');
    viewer.innerText = JSON.stringify({
      resourceType: "Bundle",
      id: `abdm-bundle-${activePatientSessionId}`,
      type: "document",
      entry: [
        { resource: { resourceType: "Composition", title: "MediKiosk Dual AYUSH-Allopathy Consultation" } },
        { resource: { resourceType: "Patient", identifier: [{ system: "https://healthid.abdm.gov.in", value: "91-4521-8890-1123" }] } }
      ]
    }, null, 2);
  }
}

function closeFhirModal() {
  const modal = document.getElementById('modal-fhir');
  if (modal.close) modal.close();
}

function copyFhirJson() {
  const text = document.getElementById('fhir-json-display').innerText;
  navigator.clipboard.writeText(text).then(() => {
    showToast('FHIR R4 JSON copied to clipboard!');
  });
}

function simulateDoctorShift() {
  showToast('Patient shared unified ABHA timeline with Dr. Ananya (Gastroenterologist)');
  setTimeout(() => {
    alert(
      '🔄 Seamless Doctor Shifting Simulated!

' +
      'Dr. Ananya (Cabin 7) has instantly loaded Rameshwar Prasad's complete pre-consultation dossier via ABHA ID 91-4521-8890-1123:
' +
      '• Ayurvedic Prakriti (Pitta-Dominant) & Tikshnagni
' +
      '• Digitized Past Prescriptions (Metformin, Atorvastatin)
' +
      '• Signed Medico-Legal Audit Trail

' +
      'No re-taking of history required! Saves 8 minutes per OPD visit.'
    );
  }, 400);
}

// ==================== TOAST NOTIFICATION ====================
function showToast(msg) {
  const toast = document.getElementById('toast-popup');
  toast.innerText = msg;
  toast.style.display = 'block';
  setTimeout(() => {
    toast.style.display = 'none';
  }, 3200);
}
