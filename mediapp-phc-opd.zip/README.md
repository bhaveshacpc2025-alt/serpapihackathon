# MediApp ⚕️ - Rural Health AI (PHC PS-133)
### AI-Powered Clinical OPD Triage & Digital Prescription Pad Dashboard

MediApp is a clinical-grade, production-ready OPD Dashboard engineered for Primary Health Centres (PHC) in rural India, integrating frontline ASHA worker telemetry with physician consultation workflows, smart Clinical Decision Support (CDSS), and Ayushman Bharat Digital Mission (ABDM) compliance.

---

## 🚀 Key Features & Architectural Highlights

### 1. Sticky Top Navigation Bar
- **Logo & Identity:** Bold `MediApp` brandmark with subtitle `"Rural Health AI - PS 133"`.
- **Live Status Flex Indicators:**
  - `PHC Unit #04` with a real-time animated green pulsing dot.
  - `Queue: 14/42` real-time patient queue monitoring badge.
  - `ABDM Gateway Connected` secure sync health badge.
- **Physician Profile & Action:**
  - Profile avatar for **Dr. Aarav** (Medical Officer).
  - Interactive **"Scan ASHA QR"** button with hover transition, opening a laser-viewfinder scanner modal that simulates syncing field-worker referrals.

### 2. Patient Info & Vitals Header (`bg-slate-50`, shadow, rounded)
- **Demographics:** `Rajesh Kumar, 45 Y / Male` with verified ABHA ID `91-4829-1848-2916` (one-click copy with clipboard feedback).
- **Triage Urgency:** Flashing animated red badge **`Priority 1 (Urgent)`** with pulsing radar indicator.
- **4-Card Telemetry Grid:**
  1. **BP (90/60 mmHg):** Highlighted in bold **red** with `Low (Hypotension)` alert.
  2. **Pulse (108 bpm):** Highlighted with `Tachycardia (>100 bpm)` badge.
  3. **SpO2 (94%):** Highlighted with `Borderline Low` saturation indicator.
  4. **Temp (104.2°F):** Highlighted in bold **red** with `High Fever (Hyperpyrexia)` ping indicator.

### 3. Main Content (Responsive CSS Grid: `grid-cols-2` with `gap-6`)

#### Left Column - "AI Patient History (Triaged by ASHA)"
- **Chief Complaint Card (`bg-rose-50`, `border-rose-200`):**
  - Text: *"High fever with severe chills and body ache for 3 days."*
- **History of Present Illness (HPI) Card (`bg-white`):**
  - Text: *"Patient referred from Sub-Centre by ASHA worker. Sudden onset of fever, vomiting, and extreme weakness."*
  - Includes clinical hydration and nausea telemetry cards.
- **ASHA Voice Transcript Card (`bg-slate-100`):**
  - Small **'Play Audio'** button that toggles to **'Pause'**, driving a live equalizer audio waveform visualizer, progress timer, and Web Speech audio dispatch.
  - Italic Hindi transcript: *"Doctor sahab, isko 3 din se bohot tez bukhar aur kampa-kampi hai..."* with English translation.
- **AI Diagnostic Tags (`bg-teal-100`, `text-teal-800`):**
  - Interactive pill tags: `#MalariaSuspect`, `#HighFever`, `#ASHA_Referred`.
  - Clicking any tag highlights the inference rationale and clinical protocol (e.g. RDT order).

#### Right Column - "Digital Prescription Pad"
- **Interactive Diagnosis Input:** Real typeable input pre-filled with `"Suspected Malaria / Dengue Fever"`, mapped to ICD-10 `B54` with one-click suggestion chips.
- **Interactive Medication Cards:**
  - **Med 1:** `Artemether-Lumefantrine 80/480mg` (Dosage: 1 Tab, BD, 3 Days) with delete trash icon.
  - **Med 2:** `Paracetamol 650mg` (Dosage: 1 Tab, SOS) with delete trash icon.
  - **"+ Add Medication" Outline Button:** Opens a modal to prescribe essential PHC medicines or custom formulations.
- **Critical CDSS Alert Box (`bg-red-50`, `border-red-500`, `text-red-700`):**
  - Prominent alert with `AlertTriangle` icon.
  - Title: **`CRITICAL CDSS ALERT`**
  - Description: *"Patient's past OCR record indicates severe allergy to Sulfa-based drugs. Avoid Sulfadoxine-Pyrimethamine."*
  - Interactive **"View OCR Evidence"** link that displays the historical scanned emergency discharge slip with highlighted allergy classification.
  - **Active Prescription Lock:** If a physician attempts to add a Sulfa drug (e.g. *Septran*, *Sulfadoxine*), the modal immediately triggers a safety lock.
- **Full-Width Action Button:**
  - **"Generate E-Prescription"** (`bg-teal-600 hover:bg-teal-700`), launching a printable, ABDM-compliant digital prescription slip with QR code, digital signature hash, and pharmacy dispensing token.

---

## 💻 Tech Stack
- **Frontend:** React 18, Tailwind CSS, Lucide React SVG icon system.
- **Design System:** Clinical palette — Slate backgrounds (`slate-50`/`slate-100`), Teal & Emerald accents (`teal-600`/`teal-700`/`emerald-500`), and Rose/Red alerts (`rose-50`/`rose-200`/`red-500`/`red-700`).
- **Zero-Dependency Direct Browser Viewing:** `frontend/standalone.html` can be opened directly in any browser (Chrome, Edge, Firefox) without any server.
- **Backend / API (Optional):** FastAPI / Python HTTP server (`run.py` / `run.bat`).

---

## 🏃 How to Run

### Option 1: Direct Double-Click (Zero Setup)
Simply open `frontend/standalone.html` in your web browser:
```
C:\Users\Brahmastra\.gemini\antigravity\scratch\mediapp\frontend\standalone.html
```

### Option 2: Run via Python Server
Double-click `run.bat` or run:
```powershell
python run.py
```
Then navigate to:
```
http://127.0.0.1:8080
```
