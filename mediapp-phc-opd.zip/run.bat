@echo off
title MediApp - Rural Health AI (PHC Dashboard)
echo ======================================================================
echo Launching MediApp Rural Health AI (PHC Unit #04)...
echo ======================================================================
cd /d "%~dp0"

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python run.py
    goto end
)

where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    py run.py
    goto end
)

if exist "..\test_venv\Scripts\python.exe" (
    ..\test_venv\Scripts\python.exe run.py
    goto end
)

echo Opening standalone frontend directly in browser...
start "" "frontend\standalone.html"

:end
pause
