#!/usr/bin/env python3
"""
MediApp Launcher - Rural Health AI - PS 133
Primary Health Centre (PHC) OPD AI Triage & CDSS Portal
"""
import os
import sys
import socket
import webbrowser
import threading
import time
from http.server import SimpleHTTPRequestHandler, HTTPServer

current_dir = os.path.dirname(os.path.abspath(__file__))
frontend_dir = os.path.join(current_dir, "frontend")
backend_dir = os.path.join(current_dir, "backend")

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0

def find_available_port(start_port=8080):
    port = start_port
    while is_port_in_use(port):
        port += 1
    return port

def print_banner(port, mode="FastAPI"):
    print("=" * 75)
    print("   MEDIAPP | Rural Health AI - PS 133")
    print("   Primary Health Centre (PHC) Clinical OPD Dashboard")
    print("=" * 75)
    print(f"   [+] Web Portal URL:       http://127.0.0.1:{port}")
    print(f"   [+] Direct Standalone:    http://127.0.0.1:{port}/standalone.html")
    print(f"   [+] Server Engine:        {mode}")
    print("-" * 75)
    print("   Active Modules:")
    print("     * Top Sticky Clinical Header (PHC Unit #04, Queue 14/42, ABDM Gateway)")
    print("     * Live Triage Stat Cards (BP 90/60, Pulse 108, SpO2 94%, Temp 104.2°F)")
    print("     * ASHA Voice Transcript & Audio Player")
    print("     * Interactive AI Tags (#MalariaSuspect, #HighFever, #ASHA_Referred)")
    print("     * Digital Prescription Pad (Typeable Diagnosis & Editable Rx Regimen)")
    print("     * Critical CDSS Alert (Sulfa-Drug Hypersensitivity Protection)")
    print("     * Official ABDM E-Prescription Generator & ASHA QR Scanner")
    print("=" * 75)
    print("   Press Ctrl+C to terminate the local server.\n")

def open_browser(port):
    time.sleep(1.2)
    webbrowser.open(f"http://127.0.0.1:{port}")

class CustomHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=frontend_dir, **kwargs)

if __name__ == "__main__":
    port = find_available_port(8080)
    
    # Try FastAPI/Uvicorn first, fall back to built-in HTTP server
    has_uvicorn = False
    try:
        import uvicorn
        if backend_dir not in sys.path:
            sys.path.insert(0, backend_dir)
        import app
        has_uvicorn = True
    except ImportError:
        has_uvicorn = False

    if has_uvicorn:
        print_banner(port, "FastAPI + Uvicorn")
        threading.Thread(target=open_browser, args=(port,), daemon=True).start()
        uvicorn.run("app:app", app_dir=backend_dir, host="127.0.0.1", port=port, reload=False)
    else:
        print_banner(port, "Built-in Python HTTP Server")
        threading.Thread(target=open_browser, args=(port,), daemon=True).start()
        server = HTTPServer(('127.0.0.1', port), CustomHandler)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down MediApp server...")
            server.server_close()
