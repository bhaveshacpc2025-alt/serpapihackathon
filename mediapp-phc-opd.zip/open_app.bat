@echo off
title Launch MediApp PHC Dashboard
echo ======================================================================
echo Opening MediApp Rural Health AI Clinical Dashboard in your browser...
echo ======================================================================
start "" "%~dp0frontend\standalone.html"
exit
