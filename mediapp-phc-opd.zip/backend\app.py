"""
app.py - MediApp FastAPI Server
Serves the Doctor Web Portal Dashboard & clinical triage API for Primary Health Centre (PHC)
Rural Health AI - PS 133
"""
import os
import sys
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

import cdss_engine

current_dir = os.path.dirname(os.path.abspath(__file__))
frontend_dir = os.path.abspath(os.path.join(current_dir, "..", "frontend"))

app = FastAPI(
    title="MediApp - Rural Health AI - PS 133",
    description="Primary Health Centre (PHC) AI-powered pre-consultation OPD triage platform with CDSS & ABDM FHIR export",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Patient Database
PATIENT_DATA = {
    "id": "PHC-PS133-9042",
    "name": "Rajesh Kumar",
    "age": 45,
    "gender": "Male",
    "abhaId": "91-4829-1848-2916",
    "triagePriority": "Priority 1 (Urgent)",
    "roomNo": "PHC Unit #04",
    "waitDuration": "14 mins",
    "vitals": {
        "bp": "90/60 mmHg",
        "pulse": 108,
        "spo2": 94,
        "temp": "104.2°F",
        "weight": "68 kg",
        "bmi": "23.5"
    },
    "chronic_conditions": [
        "Severe Sulfa Drug Allergy (Documented 2024)"
    ],
    "chiefComplaint": "High fever with severe chills and body ache for 3 days.",
    "hpi": "Patient referred from Sub-Centre by ASHA worker. Sudden onset of fever, vomiting, and extreme weakness.",
    "voiceTranscriptSnippet": "Doctor sahab, isko 3 din se bohot tez bukhar aur kampa-kampi hai...",
    "keyTags": ["#MalariaSuspect", "#HighFever", "#ASHA_Referred"],
    "ocr_records": [
        {
            "id": "doc-sulfa-1",
            "title": "Emergency Discharge Slip",
            "date": "14 Oct 2024",
            "facility": "Civil Hospital Emergency",
            "status": "Contraindication Trigger",
            "keyFinding": "Severe Type-I IgE hypersensitivity to Sulfa-containing drugs (Septran/Co-trimoxazole). Developed acute facial angioedema and urticaria.",
            "confidence": "98.7%",
            "rawSnippet": "DIAGNOSIS: Acute Bronchitis. ADR NOTE: Severe generalized allergic reaction to Tab Septran (Sulfa drug). STRICTLY AVOID ALL SULFA DERIVATIVES."
        },
        {
            "id": "doc-cbc-2",
            "title": "Peripheral Blood Smear & CBC",
            "date": "10 Mar 2025",
            "facility": "PHC Diagnostic Lab",
            "status": "Baseline",
            "keyFinding": "Hb: 12.6 g/dL, Platelets: 180,000 /cumm, TLC: 9,200 /cumm.",
            "confidence": "97.4%",
            "rawSnippet": "PLATELET COUNT: 180,000 /cumm. MALARIA PARASITE: Not detected on routine screening slide."
        }
    ]
}

class MedicineItem(BaseModel):
    name: str
    dosage: str
    instructions: Optional[str] = ""
    isBetaBlocker: Optional[bool] = False

class CDSSCheckRequest(BaseModel):
    medicines: List[MedicineItem]

class ABDMPushRequest(BaseModel):
    patientId: str
    diagnosis: str
    medicines: List[Dict[str, Any]]
    doctorNotes: Optional[str] = ""

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "service": "MediApp PHC Rural Health AI",
        "phcUnit": "PHC Unit #04",
        "abdmGateway": "CONNECTED",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

@app.get("/api/patient")
def get_patient():
    return PATIENT_DATA

@app.post("/api/cdss/evaluate")
def check_cdss(req: CDSSCheckRequest):
    meds_dict = [m.model_dump() for m in req.medicines]
    evaluation = cdss_engine.evaluate_prescription(meds_dict, PATIENT_DATA)
    return evaluation

@app.post("/api/abdm/push-prescription")
def push_abdm_prescription(req: ABDMPushRequest):
    bundle_id = f"urn:uuid:{uuid.uuid4()}"
    tx_hash = f"0x{uuid.uuid4().hex[:16]}"
    
    return {
        "status": "SUCCESS",
        "abdmCareContextId": f"PHC-CARE-{uuid.uuid4().hex[:8].upper()}",
        "fhirBundleId": bundle_id,
        "transactionHash": tx_hash,
        "patientAbha": PATIENT_DATA["abhaId"],
        "doctorSignature": "Dr. Aarav, MBBS (Reg: MCI-78491)",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "message": "Prescription successfully cryptographically signed and registered to ABDM Gateway."
    }

# Mount static files
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

@app.get("/")
def serve_index():
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return JSONResponse({"status": "Frontend not found", "path": index_path})

@app.get("/standalone")
def serve_standalone():
    standalone_path = os.path.join(frontend_dir, "standalone.html")
    if os.path.exists(standalone_path):
        return FileResponse(standalone_path)
    return JSONResponse({"status": "Standalone file not found", "path": standalone_path})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
