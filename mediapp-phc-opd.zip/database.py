"""
database.py - Common SQLite Database for MediApp (Doctor OPD) and MediKiosk (ASHA/Patient Portal)
Unified Rural Health AI - PS 133
"""
import sqlite3
import json
import os
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mediapp_shared.db")

def get_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Patients & Triage Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        token_no TEXT UNIQUE,
        name TEXT NOT NULL,
        age INTEGER,
        gender TEXT,
        phone TEXT,
        village TEXT,
        abha_id TEXT,
        abha_address TEXT,
        priority INTEGER DEFAULT 2,
        priority_label TEXT DEFAULT 'Priority 2 (Standard)',
        status TEXT DEFAULT 'Waiting',
        vitals_bp TEXT,
        vitals_pulse INTEGER,
        vitals_spo2 INTEGER,
        vitals_temp REAL,
        vitals_rr INTEGER,
        chief_complaint TEXT,
        hpi TEXT,
        symptoms_json TEXT,
        asha_transcript_hi TEXT,
        asha_transcript_en TEXT,
        ai_tags_json TEXT,
        ocr_records_json TEXT,
        diagnosis TEXT,
        doctor_notes TEXT,
        prescriptions_json TEXT,
        prescription_token TEXT,
        signed_at TEXT,
        doctor_name TEXT,
        doctor_reg TEXT,
        referral_json TEXT,
        audit_hash TEXT,
        created_at TEXT,
        updated_at TEXT
    )
    """)

    cursor.execute("SELECT COUNT(*) FROM patients")
    count = cursor.fetchone()[0]
    if count == 0:
        seed_default_patients(cursor)

    conn.commit()
    conn.close()
    print(f"Database initialized at {DB_PATH}")

def seed_default_patients(cursor):
    now = datetime.now(timezone.utc).isoformat()
    
    # 1. Rajesh Kumar - Acute Malaria with Chills & Hypotension (Sulfa Allergy Alert)
    rajesh_ocr = [
        {
            "id": "ocr-rec-01",
            "title": "Civil Hospital Discharge Card (Oct 2024)",
            "facility": "Sub-District Hospital, Wardha",
            "date": "24-Oct-2024",
            "confidence": "98.7% Confirmed",
            "highlight": "Sulfa Drug Hypersensitivity: Toxic Epidermal Necrolysis / Stevens-Johnson Overlap",
            "keyFinding": "Patient suffered generalized blistering eruption following Cotrimoxazole (Sulfamethoxazole-Trimethoprim) ingestion. Strictly contraindicated for all Sulfonamides, Cotrimoxazole, and Sulfadoxine-Pyrimethamine formulations.",
            "isAllergyAlert": True,
            "badge": "CDSS Flagged Allergy"
        },
        {
            "id": "ocr-rec-02",
            "title": "District Malaria Surveillance Card (Jun 2023)",
            "facility": "Primary Health Centre Malaria Wing",
            "date": "14-Jun-2023",
            "confidence": "96.4% Confirmed",
            "highlight": "Peripheral Blood Smear - Malaria Parasite Negative",
            "keyFinding": "Presented with intermittent pyrexia. Blood smear negative for Plasmodium at the time. Treated with empirical Paracetamol.",
            "isAllergyAlert": False,
            "badge": "Historical Baseline"
        }
    ]

    rajesh_meds = [
        {
            "id": 1,
            "name": "Artemether + Lumefantrine (Coartem)",
            "dosage": "80/480 mg",
            "frequency": "Twice daily (BD) x 3 days",
            "instructions": "Take strictly after fatty food / milk for optimal absorption"
        },
        {
            "id": 2,
            "name": "Paracetamol (Acetaminophen)",
            "dosage": "650 mg",
            "frequency": "SOS (Every 6 hours if temp > 100°F)",
            "instructions": "Do not exceed 4 tablets in 24 hours. Maintain hydration."
        }
    ]

    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        prescription_token, signed_at, doctor_name, doctor_reg,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-101", "PS-14", "Rajesh Kumar", 45, "Male", "+91 91482 91848", "Rampur Sector 4",
        "91-4829-1848-2916", "rajesh.kumar45@abdm",
        1, "Priority 1 (Urgent)", "In Consultation",
        "90/60", 108, 94, 104.2, 24,
        "High-grade fever with shaking chills, rigor, profuse sweats for 3 days. Severe prostration and dark urine noted this morning.",
        "Patient developed sudden onset chills 72 hours ago after working in paddy fields. Fever spikes up to 104°F every evening. Hypotensive on arrival (BP 90/60). Rapid diagnostic test (RDT) positive for Plasmodium falciparum.",
        json.dumps(["High Fever", "Shaking Chills", "Low BP", "Severe Headache", "Dark Urine"]),
        "नमस्ते डॉक्टर साहब, राजेश जी को ३ दिन से बहुत तेज़ ठंड लगकर बुखार आ रहा है। आज सुबह पेशाब का रंग भी गहरा था और उठने में चक्कर आ रहा है। आरडीटी किट में पी. फाल्सीपेरम पॉजिटिव आया है।",
        "Hello Doctor, Rajesh ji has acute high fever with shaking chills for 3 days. This morning urine color was notably dark and he felt severely dizzy standing up. Malaria RDT kit tested positive for P. falciparum.",
        json.dumps(["#MalariaSuspect", "#HighFever", "#ASHA_Referred", "#HypotensionAlert", "#P_Falciparum"]),
        json.dumps(rajesh_ocr),
        "Plasmodium Falciparum Malaria with Impending Hypotensive Shock",
        "Patient presenting with acute fever, rigors and hypotension (90/60). Oral rehydration started. Strictly contraindicate Sulfa antimalarials due to documented TEN history in Oct 2024.",
        json.dumps(rajesh_meds),
        None, None, "Dr. Aarav", "MCI-2018-847291",
        now, now
    ))

    # 2. Vikas Patil - Suspected Dengue Fever with Severe Thrombocytopenia & Body Aches (New Example)
    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-102", "PS-15", "Vikas Patil", 36, "Male", "+91 98221 55643", "Bori Gaon Ward 3",
        "91-5542-8819-2041", "vikas.patil@abdm",
        1, "Priority 1 (Urgent)", "Waiting",
        "100/68", 102, 97, 103.5, 22,
        "Continuous high fever (103.5°F) for 4 days with severe retro-orbital eye pain, excruciating joint/bone pain ('breakbone fever'), and petechial spots on forearms.",
        "36-year-old agricultural laborer presenting with severe aching behind eyes, anorexia and vomiting x 3 episodes. Tourniquet test positive. Rapid NS1 Dengue antigen positive. Platelet count dropping (42,000/uL).",
        json.dumps(["High Fever 103.5°F", "Retro-Orbital Pain", "Breakbone Bodyache", "Petechial Rash", "Vomiting"]),
        "डॉक्टर साहब, विकास जी को ४ दिन से आंखों के पीछे बहुत तेज़ दर्द और हड्डी-तोड़ बुखार है। बांहों पर लाल चकत्ते आ रहे हैं और प्लेटलेट ४२,००० पर आ गई है।",
        "Doctor, Vikas has high fever for 4 days with severe retro-orbital pain and deep bone pain. Red petechial rash observed on arms; platelets have dropped to 42,000/uL.",
        json.dumps(["#DengueWarning", "#Thrombocytopenia", "#BreakboneFever", "#HighFever", "#PlateletDrop"]),
        json.dumps([
            {
                "id": "ocr-rec-dengue",
                "title": "Rural Diagnostic Lab CBC Slip (Today)",
                "facility": "PHC Bori Diagnostic Unit",
                "date": "Today, 08:30 AM",
                "confidence": "99.1%",
                "highlight": "Platelet Count: 42,000 /uL | Hematocrit: 48%",
                "keyFinding": "Marked thrombocytopenia with hemoconcentration. NS1 Antigen Positive. Strict monitoring for warning signs of Dengue Shock Syndrome.",
                "isAllergyAlert": False,
                "badge": "Critical Lab Flag"
            }
        ]),
        "Acute Dengue Infection with Warning Signs (Severe Thrombocytopenia)",
        "Strict fluid management protocol initiated. Oral rehydration 2.5 L/day. Strict avoidance of NSAIDs / Aspirin / Ibuprofen due to bleeding hazard. Monitor CBC every 12 hours.",
        json.dumps([
            {"id": 1, "name": "Paracetamol (Acetaminophen)", "dosage": "500 mg", "frequency": "TDS / SOS (max 2g/day)", "instructions": "Only for temp > 101°F. Avoid NSAIDs/Brufen completely."},
            {"id": 2, "name": "Oral Rehydration Salts (WHO Formula)", "dosage": "1 Packet in 1 Litre", "frequency": "Frequent sips throughout day", "instructions": "Aim for urine output > 0.5 ml/kg/hr"}
        ]),
        now, now
    ))

    # 3. Sunita Devi - Acute Bronchial Asthma Exacerbation with Wheezing (New Example)
    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-103", "PS-16", "Sunita Devi", 52, "Female", "+91 94411 22334", "Amgaon Tola",
        "91-7782-9901-4412", "sunita.devi@abdm",
        1, "Priority 1 (Urgent)", "Waiting",
        "138/88", 112, 89, 99.1, 28,
        "Acute breathlessness, chest tightness, and loud expiratory wheezing since last midnight following crop stubble burning smoke exposure. SpO2 89% on room air.",
        "52-year-old known asthmatic woman presenting with respiratory distress (RR 28/min). Speaking in short phrases. Auscultation reveals bilateral widespread polyphonic expiratory wheezes with prolonged expiration.",
        json.dumps(["Severe Breathlessness", "Audible Wheezing", "Chest Tightness", "SpO2 89%", "Tachypnea"]),
        "सुनीता जी को रात से सांस फूलने और छाती में सीटी बजने की बहुत तकलीफ है। खेत में धुआं लगने से दौरा पड़ा है, ऑक्सीजन ८९% पर गिर गया है।",
        "Sunita ji has severe breathlessness and loud wheezing since night after exposure to crop smoke. Oxygen saturation has dropped to 89%.",
        json.dumps(["#AsthmaFlare", "#Hypoxia89", "#Wheezing", "#EmergencyNebulization"]),
        json.dumps([
            {
                "id": "ocr-rec-asthma",
                "title": "Chest Clinic Pulmonary Card (Jan 2025)",
                "facility": "District TB & Chest Hospital",
                "date": "12-Jan-2025",
                "confidence": "97.5%",
                "highlight": "Severe Persistent Asthma (GINA Step 4)",
                "keyFinding": "FEV1 54% predicted. Regular Budesonide-Formoterol inhaler prescribed. History of past ICU admission for status asthmaticus.",
                "isAllergyAlert": False,
                "badge": "Pulmonary Baseline"
            }
        ]),
        "Acute Severe Asthma Exacerbation with Moderate Hypoxemia",
        "Immediate nebulization with Salbutamol 2.5mg + Ipratropium 500mcg. Oxygen therapy via nasal prongs to maintain SpO2 > 94%. Systemic corticosteroid (Hydrocortisone IV or Prednisolone oral) indicated.",
        json.dumps([
            {"id": 1, "name": "Salbutamol + Ipratropium Respules", "dosage": "2.5mg / 500mcg", "frequency": "Stat Nebulization x 3 doses every 20 mins", "instructions": "Nebulize with high-flow oxygen"},
            {"id": 2, "name": "Tab. Prednisolone", "dosage": "40 mg", "frequency": "Once daily (OD) in morning x 5 days", "instructions": "Take after meals"}
        ]),
        now, now
    ))

    # 4. Sita Bai - 34 Weeks Pregnancy with Severe Pre-eclampsia (Original High-Risk ANC Patient)
    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-104", "PS-17", "Sita Bai", 29, "Female", "+91 98231 44512", "Shivpur Tola",
        "91-2831-7721-9041", "sitabai.anc@abdm",
        1, "Priority 1 (Urgent)", "Waiting",
        "160/105", 92, 98, 98.8, 20,
        "34 weeks pregnancy with severe persistent frontal headache, blurred vision, epigastric pain, and pitting pedal edema +3.",
        "Gravida 2, Para 1 at 34 weeks gestation. ASHA worker noted pedal edema +3 and systolic BP > 160 during village outreach. Urine dipstick shows albumin 2+. Imminent eclampsia warning signs.",
        json.dumps(["Severe Headache", "High BP 160/105", "Swollen Feet", "Epigastric Pain", "Blurry Vision"]),
        "सीता बाई ३४ हफ्ते की गर्भवती हैं। पिछले दो दिनों से सिर में भारीपन और पैरों में बहुत सूजन है। बीपी १६०/१०५ आया है।",
        "Sita Bai is 34 weeks pregnant. Having severe headache and severe leg swelling for past two days. BP measured at 160/105 mmHg.",
        json.dumps(["#ANC_HighRisk", "#PreEclampsia", "#Hypertension", "#Priority1_ANC"]),
        json.dumps([]),
        "Gestational Hypertension with Pre-eclampsia at 34 Weeks",
        "Urgent loading dose of Labetalol oral or IV under monitoring. Prepare for district hospital referral if BP remains uncontrolled.",
        json.dumps([
            {"id": 1, "name": "Labetalol", "dosage": "100 mg", "frequency": "BD", "instructions": "Take after meals, monitor BP every 4 hours"}
        ]),
        now, now
    ))

    # 5. Kavita Meena - Acute Infectious Gastroenteritis with Dehydration (New Example)
    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-105", "PS-18", "Kavita Meena", 24, "Female", "+91 97654 33211", "Meena Basti Ward 1",
        "91-6621-3304-9812", "kavita.meena@abdm",
        2, "Priority 2 (Standard)", "Waiting",
        "98/66", 104, 98, 100.2, 20,
        "Profuse watery diarrhea (8 episodes since morning), abdominal colic, recurrent nausea, dry mouth, and mild dizziness standing up.",
        "24-year-old female presenting with acute onset rice-watery stools following village community meal. Mild postural dizziness. Physical exam: sunken eyes, dry oral mucosa, skin pinch goes back slowly (Some Dehydration).",
        json.dumps(["Watery Diarrhea", "Abdominal Cramps", "Dry Mouth", "Sunken Eyes", "Nausea"]),
        "कविता को आज सुबह से ८ बार पानी जैसे पतले दस्त और उल्टी हुई है। आंखें धंस गई हैं और मुंह सूख रहा है।",
        "Kavita has had 8 episodes of watery diarrhea and vomiting since this morning. Eyes are sunken and tongue is noticeably dry.",
        json.dumps(["#AcuteGastroenteritis", "#Dehydration", "#WaterborneDiarrhea", "#ORS_Zinc"]),
        json.dumps([]),
        "Acute Infectious Gastroenteritis with Some Dehydration (WHO Plan B)",
        "Start active oral rehydration with WHO-ORS solution (75 ml/kg over 4 hours). Add Zinc supplementation for 14 days. Avoid antimotility agents.",
        json.dumps([
            {"id": 1, "name": "Oral Rehydration Salts (WHO Formula)", "dosage": "1 Litre Solution", "frequency": "Frequent sips over 4 hours", "instructions": "Mix each sachet in exactly 1 L boiled and cooled water"},
            {"id": 2, "name": "Tab. Zinc Sulfate", "dosage": "20 mg", "frequency": "Once daily (OD) x 14 days", "instructions": "Take after meals to restore intestinal mucosa"}
        ]),
        now, now
    ))

    # 6. Rameshwar Prasad - Chronic GERD / Dyspepsia (Original MediKiosk Patient)
    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        "P-106", "PS-19", "Rameshwar Prasad", 58, "Male", "+91 98765 43210", "Belagavi Rural",
        "91-4521-8890-1123", "rameshwar52@abdm",
        2, "Priority 2 (Standard)", "Waiting",
        "138/88", 82, 97, 98.4, 18,
        "Severe retrosternal burning and acid regurgitation (Amlapitta) for 4 weeks. Epigastric burning worse post-prandially and when lying down.",
        "58-year-old shopkeeper presenting with long-standing dyspepsia and sour regurgitation. Past medical history of Type 2 Diabetes Mellitus on Metformin 500mg BD. Endoscopy 2 years ago showed mild erosive gastritis.",
        json.dumps(["Acid Reflux", "Epigastric Burning", "Bloating", "Sour Burps"]),
        "मुझे पिछले एक महीने से सीने में बहुत तेज़ जलन होती है और खट्टी डकारें आती हैं। खाने के बाद जलन बढ़ जाती है।",
        "For the last one month I have intense burning sensation in my chest with acid regurgitation. Burning worsens after meals.",
        json.dumps(["#Amlapitta", "#GERD", "#Kiosk_SelfIntake", "#Dyspepsia"]),
        json.dumps([
            {
                "id": "ocr-rec-gerd",
                "title": "Dr. Gupta Clinic Prescription (Dec 2025)",
                "facility": "City Polyclinic",
                "date": "18-Dec-2025",
                "confidence": "95.1%",
                "highlight": "Past Meds: Metformin 500mg BD, Pantoprazole 40mg",
                "keyFinding": "Under treatment for Type 2 Diabetes and Reflux Esophagitis.",
                "isAllergyAlert": False,
                "badge": "OCR Extracted"
            }
        ]),
        "Gastroesophageal Reflux Disease (GERD) with Dyspepsia",
        "Dietary counseling provided. Avoid spicy/fried foods at night. Initiate PPI therapy.",
        json.dumps([
            {"id": 1, "name": "Pantoprazole", "dosage": "40 mg", "frequency": "Once daily (OD) empty stomach", "instructions": "Take 30 mins before morning breakfast"}
        ]),
        now, now
    ))
