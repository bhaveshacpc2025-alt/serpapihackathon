"""
server.py - Complete Unified Server for Doctor Portal (MediApp) & ASHA/Patient Portal (MediKiosk)
Common SQLite Database: mediapp_shared.db
"""
import os
import sys
import json
import uuid
import hashlib
import sqlite3
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, HTTPException, Request, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

# Ensure current dir is in path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import database
try:
    import clinical_engine
except ImportError:
    clinical_engine = None

# Initialize SQLite database
database.init_db()

app = FastAPI(
    title="MediApp Unified Rural Health AI & ASHA Platform",
    description="Unified API & Common SQLite Database for Doctor OPD Dashboard & ASHA/Patient Portal",
    version="2.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------- PYDANTIC REQUEST SCHEMAS -----------------
class KioskIntakeV1(BaseModel):
    name: str
    age: int
    gender: str
    phone: str
    abha_id: Optional[str] = "91-0000-0000-0000"
    preferred_lang: Optional[str] = "en"
    vitals: Dict[str, Any] = {}
    chief_complaints: List[Dict[str, Any]] = []
    known_allergies: List[str] = []
    chronic_conditions: List[str] = []
    prakriti_answers: Dict[str, str] = {}
    dashavidha: Dict[str, Any] = {}
    ocr_extracted_meds: List[str] = []

class FinalizePrescriptionRequest(BaseModel):
    patient_id: str
    diagnosis: str
    doctor_notes: Optional[str] = ""
    medications: List[Dict[str, Any]] = []
    doctor_name: Optional[str] = "Dr. Aarav"
    doctor_reg: Optional[str] = "MCI-2018-847291"
    acknowledged_contraindications: Optional[List[str]] = []

class Referral108Request(BaseModel):
    patient_id: str
    receiving_facility: Optional[str] = "District Civil Hospital & Trauma Centre, Wardha"
    reason: Optional[str] = "Emergency tertiary referral"
    checklist: Optional[List[str]] = []

# ----------------- HELPER FUNCTIONS -----------------
def row_to_patient_dict(row: sqlite3.Row) -> Dict[str, Any]:
    d = dict(row)
    for json_col in [
        "symptoms_json", "ai_tags_json", "ocr_records_json",
        "prescriptions_json", "referral_json"
    ]:
        try:
            d[json_col.replace("_json", "")] = json.loads(d.get(json_col) or "[]")
        except Exception:
            d[json_col.replace("_json", "")] = []

    # Map vitals
    d["vitals"] = {
        "bp": d.get("vitals_bp", "120/80"),
        "pulse": d.get("vitals_pulse", 72),
        "spo2": d.get("vitals_spo2", 98),
        "temp": d.get("vitals_temp", 98.6),
        "rr": d.get("vitals_rr", 18)
    }
    return d

def compute_priority(vitals: Dict[str, Any], complaint: str, symptoms: List[str]) -> tuple:
    is_urgent = False
    bp = vitals.get("bp", "120/80")
    try:
        sys_bp = int(bp.split("/")[0]) if "/" in bp else 120
        if sys_bp <= 95 or sys_bp >= 155:
            is_urgent = True
    except Exception:
        pass

    try:
        spo2 = int(vitals.get("spo2", 98))
        if spo2 <= 91:
            is_urgent = True
    except Exception:
        pass

    try:
        temp = float(vitals.get("temp", 98.6))
        if temp >= 103.0:
            is_urgent = True
    except Exception:
        pass

    all_text = (complaint + " " + " ".join(symptoms)).lower()
    urgent_keywords = ["malaria", "dengue", "chills", "wheezing", "asthma", "hypoxia", "eclampsia", "pre-eclampsia", "bleeding", "petechiae", "stridor"]
    if any(k in all_text for k in urgent_keywords):
        is_urgent = True

    if is_urgent:
        return 1, "Priority 1 (Urgent)"
    return 2, "Priority 2 (Standard)"

# ----------------- ASHA & KIOSK COMPATIBLE API (v1) -----------------

@app.get("/api/v1/prakriti-questions")
def get_prakriti_questions():
    if clinical_engine and hasattr(clinical_engine, "PRAKRITI_QUESTIONS"):
        return {"questions": clinical_engine.PRAKRITI_QUESTIONS}
    return {"questions": []}

@app.post("/api/v1/intake/calculate-prakriti")
def compute_prakriti_api(payload: Dict[str, Any]):
    if clinical_engine and hasattr(clinical_engine, "calculate_prakriti"):
        return clinical_engine.calculate_prakriti(payload.get("answers", {}))
    return {
        "vata_pct": 33.3, "pitta_pct": 33.3, "kapha_pct": 33.4,
        "primary_dosha": "Pitta", "secondary_dosha": "Vata",
        "constitution_type": "Dwandwaja (Pitta-Vata)"
    }

@app.get("/api/v1/queue")
def get_opd_queue_v1():
    """Returns the patient queue for the ASHA portal from the shared SQLite database."""
    conn = database.get_db()
    rows = conn.execute("SELECT * FROM patients ORDER BY priority ASC, created_at DESC").fetchall()
    patients = [row_to_patient_dict(r) for r in rows]
    conn.close()

    queue = []
    for p in patients:
        queue.append({
            "session_id": p["token_no"] or p["id"],
            "created_at": p["created_at"],
            "status": p["status"],
            "name": p["name"],
            "age": p["age"],
            "gender": p["gender"],
            "abha_id": p["abha_id"],
            "primary_dosha": "Pitta" if p["priority"] == 1 else "Vata",
            "constitution_type": p["priority_label"],
            "chief_complaint": p["chief_complaint"],
            "emergency_red_flag": p["priority"] == 1
        })
    return {"queue": queue, "total_waiting": len([q for q in queue if q["status"] in ["Waiting", "In Consultation"]])}

@app.get("/api/v1/patient/{session_id}")
def get_patient_dossier_v1(session_id: str):
    """Fetches patient dossier for ASHA portal from SQLite."""
    conn = database.get_db()
    row = conn.execute("SELECT * FROM patients WHERE id = ? OR token_no = ?", (session_id, session_id)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Patient session not found")
    p = row_to_patient_dict(row)

    return {
        "session_id": p["token_no"] or p["id"],
        "created_at": p["created_at"],
        "status": p["status"],
        "patient": {
            "name": p["name"],
            "age": p["age"],
            "gender": p["gender"],
            "abha_id": p["abha_id"],
            "abha_address": p["abha_address"],
            "phone": p["phone"],
            "preferred_lang": "Hindi"
        },
        "allopathic_triage": {
            "vitals": p["vitals"],
            "chief_complaints": [{"symptom": s, "duration": "3 days", "severity": 8} for s in p.get("symptoms", [])] or [{"symptom": p["chief_complaint"], "duration": "3 days", "severity": 8}],
            "known_allergies": ["Sulfa drugs"] if "sulfa" in json.dumps(p.get("ocr_records", [])).lower() else ["No known drug allergies"],
            "chronic_conditions": [p["chief_complaint"]],
            "emergency_red_flag": p["priority"] == 1
        },
        "ayush_assessment": {
            "prakriti": {
                "vata_pct": 25.0, "pitta_pct": 60.0, "kapha_pct": 15.0,
                "primary_dosha": "Pitta" if p["priority"] == 1 else "Vata",
                "secondary_dosha": "Vata",
                "constitution_type": p["priority_label"]
            },
            "dashavidha": {
                "agni": "Tikshnagni" if p["priority"] == 1 else "Mandagni",
                "bala": "Madhyama (Moderate)",
                "desha": "Anupa (Humid/Marshy)",
                "satmya": "Satmya standard"
            }
        },
        "digitized_ocr_baseline": {
            "extracted_past_medications": [m["name"] for m in p.get("prescriptions", [])] or ["Paracetamol 650mg"],
            "past_diagnoses": [p["diagnosis"]],
            "source_document_name": "Scanned_Prescription_Card.jpg"
        },
        "consultation_outcome": {
            "diagnosis": p["diagnosis"],
            "prescriptions": p.get("prescriptions", []),
            "token": p.get("prescription_token")
        } if p["status"] == "Completed" else None
    }

@app.post("/api/v1/intake/submit")
def submit_asha_intake_v1(intake: KioskIntakeV1):
    """
    Called when patient/ASHA submits from the ASHA Portal (medikiosk).
    Saves directly to SQLite (mediapp_shared.db) -> Reflects in Doctor OPD Portal immediately!
    """
    conn = database.get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM patients")
    count = cursor.fetchone()[0]

    new_id = f"P-{101 + count}"
    new_token = f"PS-{14 + count}"
    now = datetime.now(timezone.utc).isoformat()

    symptoms_list = [c.get("symptom", "") for c in intake.chief_complaints if c.get("symptom")]
    complaint_text = ", ".join(symptoms_list) if symptoms_list else "General acute consultation requested via ASHA kiosk."
    priority, priority_label = compute_priority(intake.vitals, complaint_text, symptoms_list)

    # Check allergies from OCR meds or complaints
    is_sulfa_alert = any("sulfa" in str(x).lower() for x in (intake.known_allergies + intake.ocr_extracted_meds))
    ocr_docs = []
    if is_sulfa_alert or "malaria" in complaint_text.lower():
        ocr_docs.append({
            "id": "ocr-rec-uploaded",
            "title": "Historical Discharge Slip (OCR Scanned)",
            "facility": "Sub-District Civil Hospital",
            "date": "Oct 2024",
            "confidence": "98.7% Confirmed",
            "highlight": "Sulfa Drug Hypersensitivity (Stevens-Johnson / TEN warning)",
            "keyFinding": "Patient has severe documented hypersensitivity to Cotrimoxazole / Sulfonamides. Strictly contraindicated.",
            "isAllergyAlert": True,
            "badge": "CDSS Flagged Allergy"
        })

    # AI tags
    ai_tags = ["#ASHA_Upload", f"#{intake.name.replace(' ', '')}"]
    if priority == 1:
        ai_tags.append("#Priority1_Urgent")
    if "fever" in complaint_text.lower():
        ai_tags.append("#HighFever")
    if "dengue" in complaint_text.lower():
        ai_tags.append("#DengueSuspect")
    if "asthma" in complaint_text.lower() or "wheez" in complaint_text.lower():
        ai_tags.append("#AsthmaFlare")

    cursor.execute("""
    INSERT INTO patients (
        id, token_no, name, age, gender, phone, village, abha_id, abha_address,
        priority, priority_label, status,
        vitals_bp, vitals_pulse, vitals_spo2, vitals_temp, vitals_rr,
        chief_complaint, hpi, symptoms_json,
        asha_transcript_hi, asha_transcript_en, ai_tags_json,
        ocr_records_json, diagnosis, doctor_notes, prescriptions_json,
        created_at, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?
    )
    """, (
        new_id, new_token, intake.name, intake.age, intake.gender, intake.phone, "PHC Catchment Area",
        intake.abha_id, f"{intake.name.lower().replace(' ', '')}@abdm",
        priority, priority_label, "Waiting",
        str(intake.vitals.get("bp", "120/80")),
        int(intake.vitals.get("pulse", 78)),
        int(intake.vitals.get("spo2", 98)),
        float(intake.vitals.get("temp", 98.6)),
        20,
        complaint_text,
        f"Intake submitted via ASHA Community Portal. Symptoms: {complaint_text}. Vitals recorded at frontline check-in.",
        json.dumps(symptoms_list),
        f"नमस्ते डॉक्टर साहब, मरीज़ {intake.name} को {complaint_text} की शिकायत है। आशा पोर्टल से पंजीकरण किया गया है।",
        f"Patient {intake.name} registered via ASHA Portal presenting with {complaint_text}.",
        json.dumps(ai_tags),
        json.dumps(ocr_docs),
        "Pending Doctor Review",
        "Awaiting in-clinic OPD consultation with Dr. Aarav.",
        json.dumps([]),
        now, now
    ))
    conn.commit()
    conn.close()

    prakriti_res = {
        "vata_pct": 30.0, "pitta_pct": 55.0, "kapha_pct": 15.0,
        "primary_dosha": "Pitta" if priority == 1 else "Vata",
        "constitution_type": priority_label
    }

    return {
        "status": "Success",
        "session_id": new_token,
        "token_no": new_token,
        "patient_id": new_id,
        "message": f"Pre-consultation intake recorded for {intake.name}. Reflected in Doctor OPD Queue (#{new_token}).",
        "prakriti": prakriti_res
    }

@app.post("/api/v1/ocr/scan-document")
def scan_medical_document_v1():
    return {
        "document_name": "Scanned_Prescription_Card.jpg",
        "detected_text": [
            "Rx: Tab Metformin 500mg BD after meals",
            "History: Acute fever with rigors, chills",
            "Allergy Alert: Cotrimoxazole (Sulfa) hypersensitivity"
        ],
        "structured_extraction": {
            "prescriptions": ["Metformin 500mg BD", "Paracetamol 650mg SOS"],
            "diagnoses": ["Acute Febrile Illness", "Sulfa Hypersensitivity"],
            "confidence": 0.98
        }
    }

@app.post("/api/v1/consultation/check-alerts")
def check_prescription_safety_v1(payload: Dict[str, Any]):
    return {
        "alerts_count": 1,
        "alerts": [
            {
                "severity": "CRITICAL",
                "message": "Sulfa Drug Contraindication: Patient has documented TEN/SJS allergy to Sulfonamide medications."
            }
        ]
    }

@app.post("/api/v1/consultation/finalize")
def finalize_consultation_v1(payload: Dict[str, Any]):
    sid = payload.get("session_id")
    conn = database.get_db()
    cursor = conn.cursor()
    now = datetime.now(timezone.utc).isoformat()
    random_hash = hashlib.sha256(f"{sid}:{now}".encode()).hexdigest()[:12].upper()
    token = f"ABDM-RX-2026-{random_hash}"

    cursor.execute("""
    UPDATE patients SET
        status = 'Completed',
        diagnosis = ?,
        doctor_notes = ?,
        prescriptions_json = ?,
        prescription_token = ?,
        signed_at = ?,
        updated_at = ?
    WHERE id = ? OR token_no = ?
    """, (
        payload.get("provisional_diagnosis", "Evaluated and Treated"),
        payload.get("doctor_notes", "Consultation finalized."),
        json.dumps(payload.get("prescriptions", [])),
        token, now, now, sid, sid
    ))
    conn.commit()
    conn.close()
    return {"status": "Success", "session_id": sid, "prescription_token": token}

# ----------------- DOCTOR PORTAL REST API -----------------

@app.get("/api/patients")
def get_doctor_patients():
    """Returns all queued and registered patients in the shared database."""
    conn = database.get_db()
    rows = conn.execute("SELECT * FROM patients ORDER BY priority ASC, created_at DESC").fetchall()
    patients = [row_to_patient_dict(r) for r in rows]
    conn.close()

    total_waiting = len([p for p in patients if p["status"] in ["Waiting", "In Consultation"]])
    urgent_count = len([p for p in patients if p["priority"] == 1])

    return {
        "patients": patients,
        "total_count": len(patients),
        "total_waiting": total_waiting,
        "urgent_count": urgent_count
    }

@app.get("/api/patients/{patient_id}")
def get_doctor_patient_by_id(patient_id: str):
    conn = database.get_db()
    row = conn.execute("SELECT * FROM patients WHERE id = ? OR token_no = ?", (patient_id, patient_id)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Patient record not found")
    return row_to_patient_dict(row)

@app.post("/api/kiosk/intake")
def create_kiosk_intake_alias(req: Request):
    """Bridge for any client sending to /api/kiosk/intake."""
    return submit_asha_intake_v1

@app.post("/api/prescriptions")
def finalize_prescription_doctor(req: FinalizePrescriptionRequest):
    """Doctor signs E-Prescription in Doctor OPD Dashboard -> Saved to SQLite."""
    conn = database.get_db()
    cursor = conn.cursor()

    row = cursor.execute("SELECT * FROM patients WHERE id = ? OR token_no = ?", (req.patient_id, req.patient_id)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Patient record not found")

    now = datetime.now(timezone.utc).isoformat()
    random_hash = hashlib.sha256(f"{req.patient_id}:{now}".encode()).hexdigest()[:12].upper()
    prescription_token = f"ABDM-RX-2026-{random_hash}"
    audit_data = f"{req.patient_id}|{req.diagnosis}|{json.dumps(req.medications)}|{now}"
    audit_hash = hashlib.sha256(audit_data.encode()).hexdigest()

    cursor.execute("""
    UPDATE patients SET
        status = 'Completed',
        diagnosis = ?,
        doctor_notes = ?,
        prescriptions_json = ?,
        prescription_token = ?,
        signed_at = ?,
        doctor_name = ?,
        doctor_reg = ?,
        audit_hash = ?,
        updated_at = ?
    WHERE id = ? OR token_no = ?
    """, (
        req.diagnosis,
        req.doctor_notes,
        json.dumps(req.medications),
        prescription_token,
        now,
        req.doctor_name,
        req.doctor_reg,
        audit_hash,
        now,
        req.patient_id,
        req.patient_id
    ))
    conn.commit()
    conn.close()

    return {
        "status": "success",
        "prescription_token": prescription_token,
        "signed_at": now,
        "audit_hash": audit_hash,
        "message": f"E-Prescription successfully signed by {req.doctor_name}. Synced to Common Database."
    }

@app.post("/api/referrals/108")
def dispatch_108_referral_doctor(req: Referral108Request):
    """Doctor dispatches 108 ALS Ambulance -> Saved to SQLite."""
    conn = database.get_db()
    cursor = conn.cursor()

    now = datetime.now(timezone.utc).isoformat()
    referral_details = {
        "referral_id": f"SOS-108-{uuid.uuid4().hex[:6].upper()}",
        "dispatched_at": now,
        "vehicle_no": "MH-31-EM-1082",
        "ambulance_type": "Advanced Life Support (ALS)",
        "receiving_facility": req.receiving_facility,
        "clinical_reason": req.reason,
        "stabilization_checklist": req.checklist or ["IV Cannulation (18G)", "Normal Saline Bolus", "O2 Support"],
        "eta_minutes": 12,
        "gps_status": "En Route (2.4 km away, Lat: 20.7453, Lng: 78.5982)"
    }

    cursor.execute("""
    UPDATE patients SET
        status = 'Referred (108 ALS En Route)',
        referral_json = ?,
        updated_at = ?
    WHERE id = ? OR token_no = ?
    """, (
        json.dumps(referral_details),
        now,
        req.patient_id,
        req.patient_id
    ))
    conn.commit()
    conn.close()

    return {
        "status": "success",
        "referral": referral_details,
        "message": "108 ALS Ambulance dispatched. Recorded in Common Database."
    }

@app.get("/api/patient/{patient_id}/passport")
def get_care_passport(patient_id: str):
    conn = database.get_db()
    row = conn.execute("SELECT * FROM patients WHERE id = ? OR token_no = ?", (patient_id, patient_id)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Patient record not found")
    p = row_to_patient_dict(row)
    return {
        "token_no": p["token_no"],
        "name": p["name"],
        "age": p["age"],
        "gender": p["gender"],
        "abha_id": p["abha_id"],
        "priority_label": p["priority_label"],
        "status": p["status"],
        "vitals": p["vitals"],
        "chief_complaint": p["chief_complaint"],
        "diagnosis": p["diagnosis"],
        "doctor_name": p.get("doctor_name"),
        "prescriptions": p.get("prescriptions", []),
        "prescription_token": p.get("prescription_token"),
        "signed_at": p.get("signed_at"),
        "is_completed": p["status"] == "Completed",
        "is_referred": "Referred" in p["status"]
    }

# ----------------- STATIC & WEB PORTAL ROUTING -----------------
frontend_dir = os.path.join(current_dir, "frontend")
asha_frontend_dir = os.path.join(frontend_dir, "asha")

@app.get("/")
@app.get("/doctor")
def serve_doctor_portal():
    """Serves the Doctor OPD Dashboard (MediApp)."""
    path = os.path.join(frontend_dir, "standalone.html")
    if os.path.exists(path):
        return FileResponse(path)
    return FileResponse(os.path.join(frontend_dir, "index.html"))

@app.get("/asha")
@app.get("/kiosk")
def serve_asha_portal():
    """Serves the ASHA / Patient Intake Portal (MediKiosk)."""
    path = os.path.join(asha_frontend_dir, "index.html")
    if os.path.exists(path):
        return FileResponse(path)
    # fallback to kiosk.html if asha dir not found
    fallback = os.path.join(frontend_dir, "kiosk.html")
    if os.path.exists(fallback):
        return FileResponse(fallback)
    return {"message": "ASHA portal loading..."}

# Mount static directories
if os.path.exists(asha_frontend_dir):
    app.mount("/asha", StaticFiles(directory=asha_frontend_dir, html=True), name="asha_static")

if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=False)
