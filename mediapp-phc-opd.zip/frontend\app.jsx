const { useState, useEffect, useRef, useMemo } = React;

// --- High Fidelity SVG Icons matching Lucide React ---
const Icon = ({ name, className = 'w-4 h-4', ...props }) => {
  const icons = {
    externalLink: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
      </svg>
    ),
    logIn: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
      </svg>
    ),
    logOut: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
    ),
    smartphone: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>
      </svg>
    ),
    stethoscope: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/><path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4"/><circle cx="20" cy="10" r="2"/>
      </svg>
    ),
    qrcode: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/>
      </svg>
    ),
    alertTriangle: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
    ),
    play: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polygon points="6 3 20 12 6 21 6 3"/>
      </svg>
    ),
    pause: (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>
      </svg>
    ),
    trash2: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>
      </svg>
    ),
    plus: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M5 12h14"/><path d="M12 5v14"/>
      </svg>
    ),
    shieldCheck: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.8 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>
      </svg>
    ),
    activity: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
      </svg>
    ),
    heartPulse: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>
      </svg>
    ),
    thermometer: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z"/>
      </svg>
    ),
    wind: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>
      </svg>
    ),
    users: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    ),
    checkCircle2: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>
      </svg>
    ),
    fileText: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>
      </svg>
    ),
    pill: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/>
      </svg>
    ),
    sparkles: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>
      </svg>
    ),
    x: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/>
      </svg>
    ),
    copy: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
      </svg>
    ),
    check: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polyline points="20 6 9 17 4 12"/>
      </svg>
    ),
    volume2: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
      </svg>
    ),
    printer: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/>
      </svg>
    ),
    fileCheck: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m9 15 2 2 4-4"/>
      </svg>
    ),
    history: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>
      </svg>
    ),
    zoomIn: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/>
      </svg>
    ),
    ambulance: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M10 10H6"/><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.28a1 1 0 0 0-.684-.948l-1.923-.641a1 1 0 0 1-.578-.5a1 1 0 0 1-.129-.53V10a2 2 0 0 0-2-2h-2v10h2"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>
      </svg>
    ),
    refreshCw: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21h5v-5"/>
      </svg>
    ),
    search: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
      </svg>
    ),
    send: (
      <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
      </svg>
    )
  };
  return icons[name] || null;
};

// --- Multi-Patient Dataset for Real PHC Triage Queue ---
const PATIENTS_QUEUE = [
  {
    id: "PS-14",
    name: "Rajesh Kumar",
    age: "45 Y",
    gender: "Male",
    abhaId: "91-4829-1848-2916",
    village: "Rampur Kalan (6 km)",
    ashaWorker: "Sunita Devi (Sub-Centre 02)",
    priority: "Priority 1 (Urgent)",
    isUrgent: true,
    conditionSummary: "Acute Febrile Illness • Suspected Falciparum Malaria with Low BP",
    vitals: {
      bp: "90/60",
      bpUnit: "mmHg",
      bpAlert: "Low (Hypotension)",
      bpAlertColor: "text-rose-600",
      pulse: 108,
      pulseAlert: "Tachycardia",
      spo2: 94,
      spo2Alert: "Borderline Low",
      temp: "104.2",
      tempAlert: "High Fever",
      tempAlertColor: "text-rose-600",
    },
    chiefComplaint: "High fever with severe chills and body ache for 3 days.",
    hpi: "Patient referred from Sub-Centre by ASHA worker. Sudden onset of fever, vomiting, and extreme weakness.",
    voiceNote: {
      hindi: "Doctor sahab, isko 3 din se bohot tez bukhar aur kampa-kampi hai...",
      english: "Doctor sir, he has had very high fever and severe shivering for 3 days. Vomiting and weakness as well.",
      duration: "0:14",
      audioFile: "ASHA_Voice_Note_0924.aac"
    },
    tags: ["#MalariaSuspect", "#HighFever", "#ASHA_Referred"],
    diagnosis: "Suspected Malaria / Dengue Fever",
    defaultMeds: [
      { id: 1, name: "Artemether-Lumefantrine 80/480mg", dosage: "1 Tab, BD, 3 Days", instructions: "Take with milk or meal to enhance bioavailability", type: "ACT Antimalarial" },
      { id: 2, name: "Paracetamol 650mg", dosage: "1 Tab, SOS", instructions: "For high fever spikes > 101°F (Max 3 tabs/day)", type: "Antipyretic / Analgesic" }
    ],
    cdss: {
      title: "CRITICAL CDSS ALERT",
      description: "Patient's past OCR record indicates severe allergy to Sulfa-based drugs. Avoid Sulfadoxine-Pyrimethamine.",
      evidenceDocId: "ocr-doc-1"
    }
  },
  {
    id: "PS-15",
    name: "Sita Bai",
    age: "32 Y",
    gender: "Female",
    abhaId: "91-4029-4821-9921",
    village: "Dhanora Outpost (8 km)",
    ashaWorker: "Kavita Tai (ANM-04)",
    priority: "Priority 1 (Urgent)",
    isUrgent: true,
    conditionSummary: "34 Weeks ANC • Severe Hypertension / Pre-eclampsia Risk",
    vitals: {
      bp: "160/100",
      bpUnit: "mmHg",
      bpAlert: "Severe Pre-HTN",
      bpAlertColor: "text-rose-600",
      pulse: 98,
      pulseAlert: "Normal",
      spo2: 97,
      spo2Alert: "Normal",
      temp: "98.6",
      tempAlert: "Normal",
      tempAlertColor: "text-slate-800",
    },
    chiefComplaint: "Severe persistent frontal headache and blurred vision for 2 days.",
    hpi: "Gravida 2 at 34 weeks gestation. Bilateral pedal edema (3+) noted by ANM. Urine albumin positive (+++).",
    voiceNote: {
      hindi: "Bohot teez sar me dard hai aur aakhon ke aage andhera aa raha hai, paanv me sujan hai...",
      english: "Severe headache and visual blurring since 2 days, marked swelling in bilateral lower limbs.",
      duration: "0:22",
      audioFile: "ASHA_Voice_Note_0925.aac"
    },
    tags: ["#PreeclampsiaSuspect", "#HighBP_ANC", "#ASHA_Referred"],
    diagnosis: "Severe Gestational Hypertension / Impending Eclampsia",
    defaultMeds: [
      { id: 11, name: "Inj. Magnesium Sulfate 50%", dosage: "4g IV + 10g IM Loading", instructions: "Pritchard protocol loading dose before district transfer", type: "Anticonvulsant" },
      { id: 12, name: "Tab. Labetalol 200mg", dosage: "1 Tab STAT Oral", instructions: "Administer immediately to lower MAP", type: "Antihypertensive" }
    ],
    cdss: {
      title: "OBSTETRIC CDSS EMERGENCY",
      description: "Severe hypertension (160/100) with visual symptoms in 3rd trimester. Imminent eclampsia risk. Immediate 108 referral required.",
      evidenceDocId: null
    }
  },
  {
    id: "PS-16",
    name: "Aarav Madavi",
    age: "2 Months",
    gender: "Male (Infant)",
    abhaId: "91-1149-5502-3391",
    village: "Kurkheda Forest (14 km)",
    ashaWorker: "Rekha Tai (ANM-07)",
    priority: "Priority 2 (Moderate)",
    isUrgent: false,
    conditionSummary: "Pediatric Acute Respiratory Infection • Chest Indrawing",
    vitals: {
      bp: "88/58",
      bpUnit: "mmHg",
      bpAlert: "Infant Normal",
      bpAlertColor: "text-slate-800",
      pulse: 146,
      pulseAlert: "Pediatric Rate",
      spo2: 93,
      spo2Alert: "Borderline Hypoxia",
      temp: "101.8",
      tempAlert: "Moderate Fever",
      tempAlertColor: "text-rose-600",
    },
    chiefComplaint: "Fast breathing, chest congestion and difficulty in breastfeeding for 24 hours.",
    hpi: "Infant presenting with cough, fever and fast breathing (RR 62/min). Mild subcostal indrawing noted.",
    voiceNote: {
      hindi: "Bacche ki chhati bohot teez chal rahi hai aur doodh nahi pee pa raha hai...",
      english: "Infant has rapid respiratory rate and difficulty latching or feeding.",
      duration: "0:18",
      audioFile: "ASHA_Voice_Note_0926.aac"
    },
    tags: ["#PediatricARI", "#FastBreathing", "#IMNCI_Protocol"],
    diagnosis: "Severe Acute Bronchiolitis / Pneumonia (IMNCI)",
    defaultMeds: [
      { id: 21, name: "Humidified Oxygen Support", dosage: "1-2 L/min Nasal Prongs", instructions: "Maintain SpO2 >= 95%", type: "Respiratory" },
      { id: 22, name: "Syp. Paracetamol 120mg/5ml", dosage: "2.5 ml SOS", instructions: "For temperature > 100°F", type: "Antipyretic" }
    ],
    cdss: {
      title: "IMNCI CLINICAL ALERT",
      description: "Infant < 2 months with tachypnea (>60/min) and SpO2 93%. Initiate warm humidified O2 and arrange cold-chain ambulance transfer.",
      evidenceDocId: null
    }
  }
];

// --- Historical OCR Records Database ---
const OCR_RECORDS_DATA = [
  {
    id: "ocr-doc-1",
    title: "Civil Hospital Emergency Discharge Slip",
    date: "14 Oct 2024",
    facility: "District Civil Hospital - Emergency Medicine Wing",
    category: "Hospital Discharge & Adverse Reaction Report",
    severity: "CRITICAL",
    badge: "⚠️ Allergy Trigger (Sulfa Hypersensitivity)",
    badgeColor: "bg-red-100 text-red-800 border-red-300",
    confidence: "98.7%",
    finding: "Severe Type-I IgE anaphylactoid reaction to Tab Septran (Sulfa drug). Acute facial angioedema and urticaria. STRICTLY AVOID ALL SULFA DERIVATIVES.",
    rawSnippet: `DISTRICT CIVIL HOSPITAL - DEPT OF EMERGENCY MEDICINE
PATIENT: RAJESH KUMAR | AGE: 44 | GENDER: MALE | OPD REG: #EM-8821
DATE OF ADMISSION: 14-OCT-2024 | DISCHARGE: 16-OCT-2024

*** ADVERSE DRUG REACTION REPORT (CRITICAL ALERT) ***
OFFENDING AGENT: TAB. SEPTRAN DS (SULFAMETHOXAZOLE 800MG + TRIMETHOPRIM 160MG)
SYMPTOMS: FACIAL ANGIOEDEMA, EXTENSIVE WHEALS, TACHYCARDIA & WHEEZING WITHIN 2 HOURS.
EMERGENCY RX: IV HYDROCORTISONE 100MG + IV AVIL STAT. REVERSED WITH RECOVERY.

CLINICAL DIRECTIVE ON DISCHARGE:
1. STRICT CONTRAINDICATION: AVOID ALL SULFA DRUGS (SULFADOXINE-PYRIMETHAMINE, SULFAMETHOXAZOLE, DAPSONE).
2. HIGH ANAPHYLAXIS RISK WITH SULFA ANTIMALARIALS.
DOCTOR: DR. V. K. MISHRA, MD (REG #62819)`,
    keyHighlights: ["Sulfa Allergy", "Angioedema", "Avoid Sulfadoxine-Pyrimethamine"],
    timelineTag: "Discharge Slip"
  },
  {
    id: "ocr-doc-2",
    title: "Peripheral Blood Smear & Complete Blood Count",
    date: "10 Mar 2025",
    facility: "PHC Diagnostic Laboratory PS-133",
    category: "Hematology Lab Slip",
    severity: "NORMAL",
    badge: "Baseline Lab Record",
    badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-300",
    confidence: "97.4%",
    finding: "Hemoglobin: 12.6 g/dL, Platelets: 180,000 /cumm, TLC: 9,200 /cumm. Malaria parasite not detected on routine baseline smear.",
    rawSnippet: `PHC DIAGNOSTIC LABORATORY - UNIT #04 (PS 133)
PATIENT: RAJESH KUMAR (45 Y / M) | ABHA: 91-4829-1848-2916
DATE: 10-MAR-2025 10:15 AM

- HEMOGLOBIN (Hb): 12.6 g/dL (Normal: 13.0 - 17.0)
- TOTAL LEUKOCYTE COUNT (TLC): 9,200 /cumm (Normal: 4,000 - 11,000)
- PLATELET COUNT: 180,000 /cumm (Normal: 150,000 - 450,000)
- PERIPHERAL BLOOD SMEAR: Normocytic normochromic. No ring-form trophozoites on current slide.
LAB IN-CHARGE: R. K. VERMA, DMLT`,
    keyHighlights: ["Hb 12.6", "Platelets 180k", "No Parasites"],
    timelineTag: "Laboratory CBC"
  },
  {
    id: "ocr-doc-3",
    title: "Sub-Centre Field Health Referral Slip",
    date: "05 Jul 2024",
    facility: "Sub-Centre Rampur Kalan (HWC)",
    category: "Frontline Community Care",
    severity: "INFO",
    badge: "Historical Triage",
    badgeColor: "bg-slate-100 text-slate-800 border-slate-300",
    confidence: "96.2%",
    finding: "Prior transient fever episode. Malaria dual RDT card was negative. Patient has recorded Sulfa drug contraindication note.",
    rawSnippet: `AYUSHMAN AROGYA MANDIR - SUB-CENTRE RAMPUR KALAN
ASHA WORKER: SUNITA DEVI (ID: 7821)
PATIENT: RAJESH KUMAR | VILLAGE: RAMPUR | DATE: 05-JUL-2024

COMPLAINT: LOW GRADE FEVER (1 DAY), BODY ACHE.
VITAL SIGNS: BP 118/76 mmHg, PULSE 82 bpm, TEMP 99.8°F.
RAPID DIAGNOSTIC TEST (Pf / Pv): NEGATIVE (C-band only).
ASHA NOTE: PATIENT HAS SULFA ALLERGY - DO NOT DISPENSE SULFA BLISTER PACKS.`,
    keyHighlights: ["RDT Neg (2024)", "Sulfa Warning Flagged"],
    timelineTag: "Field Triage Slip"
  }
];

// --- Main Application Component ---
function MediAppPHCDashboard() {
  // Common Database Queue State
  const [patientsQueue, setPatientsQueue] = useState(PATIENTS_QUEUE);
  const [currentPatientIndex, setCurrentPatientIndex] = useState(0);
  const patient = patientsQueue[currentPatientIndex] || PATIENTS_QUEUE[0];
  const [dbConnected, setDbConnected] = useState(false);

  // PrescriptionPad State
  const [diagnosis, setDiagnosis] = useState(patient.diagnosis);
  const [medicines, setMedicines] = useState(patient.defaultMeds);
  const [doctorNotes, setDoctorNotes] = useState(
    "Patient presenting with acute fever, rigors and hypotension (90/60). Oral rehydration started. Awaiting RDT blood smear confirmation."
  );

  // Sync state whenever active patient changes
  useEffect(() => {
    setDiagnosis(patient.diagnosis);
    setMedicines(patient.defaultMeds);
    setIsPlayingAudio(false);
    setAudioProgress(0);
  }, [currentPatientIndex]);

  // Poll Common Database (mediapp_shared.db via /api/patients)
  const fetchDbPatients = async () => {
    try {
      const res = await fetch('/api/patients');
      if (res.ok) {
        const data = await res.json();
        setDbConnected(true);
        if (data.patients && data.patients.length > 0) {
          const mapped = data.patients.map((p, idx) => {
            const vitalsBp = p.vitals?.bp || p.vitals_bp || "120/80";
            const vitalsPulse = p.vitals?.pulse || p.vitals_pulse || 72;
            const vitalsSpo2 = p.vitals?.spo2 || p.vitals_spo2 || 98;
            const vitalsTemp = String(p.vitals?.temp || p.vitals_temp || "98.6");

            return {
              id: p.token_no || `PS-${14 + idx}`,
              dbId: p.id,
              name: p.name,
              age: `${p.age} Y`,
              gender: p.gender,
              abhaId: p.abha_id || "91-0000-0000-0000",
              village: p.village || "PHC Catchment Area",
              ashaWorker: p.gender === "Female" && p.name.includes("Sita") ? "Sunita Devi (ANM-04)" : "Rekha Tai (HWC)",
              priority: p.priority_label || (p.priority === 1 ? "Priority 1 (Urgent)" : "Priority 2 (Standard)"),
              isUrgent: p.priority === 1,
              status: p.status || "Waiting",
              conditionSummary: p.chief_complaint || "Acute clinical presentation",
              vitals: {
                bp: vitalsBp,
                bpUnit: "mmHg",
                bpAlert: vitalsBp.startsWith("90") ? "Hypotension" : (vitalsBp.startsWith("160") ? "Severe HTN" : "Normal"),
                bpAlertColor: vitalsBp.startsWith("90") || vitalsBp.startsWith("160") ? "text-rose-600" : "text-slate-800",
                pulse: vitalsPulse,
                pulseAlert: vitalsPulse > 100 ? "Tachycardia" : "Normal",
                spo2: vitalsSpo2,
                spo2Alert: vitalsSpo2 < 95 ? "Borderline Hypoxia" : "Normal",
                temp: vitalsTemp,
                tempAlert: parseFloat(vitalsTemp) > 102 ? "High Fever" : "Normal",
                tempAlertColor: parseFloat(vitalsTemp) > 102 ? "text-rose-600" : "text-slate-800"
              },
              chiefComplaint: p.chief_complaint || "",
              hpi: p.hpi || "",
              voiceNote: {
                hindi: p.asha_transcript_hi || "नमस्ते डॉक्टर साहब, मरीज़ को बुखार आ रहा है...",
                english: p.asha_transcript_en || "Patient presenting with acute symptoms...",
                duration: "0:24",
                audioFile: "ASHA_Voice_Note.aac"
              },
              tags: p.ai_tags || ["#RuralHealthAI", "#SharedDB"],
              diagnosis: p.diagnosis && p.diagnosis !== "Pending Doctor Review" ? p.diagnosis : (p.name.includes("Rajesh") ? "Plasmodium Falciparum Malaria with Impending Hypotensive Shock" : (p.name.includes("Sita") ? "Gestational Hypertension with Pre-eclampsia at 34 Weeks" : "Provisional Evaluation Required")),
              defaultMeds: (p.prescriptions && p.prescriptions.length > 0) ? p.prescriptions : (
                p.name.includes("Rajesh") ? [
                  { id: 1, name: "Artemether + Lumefantrine", dosage: "80/480 mg", instructions: "Twice daily with meals", type: "Antimalarial" },
                  { id: 2, name: "Paracetamol", dosage: "650 mg", instructions: "SOS for temp > 100°F", type: "Antipyretic" }
                ] : [
                  { id: 11, name: "Labetalol 100mg", dosage: "1 Tab BD", instructions: "Take after meals", type: "Antihypertensive" }
                ]
              ),
              cdss: (p.ocr_records && p.ocr_records.some(r => r.isAllergyAlert)) || p.name.includes("Rajesh") ? {
                title: "CDSS CONTRAINDICATION ALERT",
                description: "Documented Sulfa Drug Hypersensitivity (Stevens-Johnson / TEN reaction). Strictly avoid Cotrimoxazole and Sulfonamide antimalarials.",
                evidenceDocId: "ocr-rec-01"
              } : null
            };
          });

          // Check if new patient registered from Kiosk
          if (mapped.length > patientsQueue.length) {
            const newPat = mapped[mapped.length - 1];
            showToast(`New Patient Checked In from Kiosk: ${newPat.name} (${newPat.id})!`);
          }

          setPatientsQueue(mapped);
        }
      }
    } catch (e) {
      setDbConnected(false);
    }
  };

  useEffect(() => {
    fetchDbPatients();
    const interval = setInterval(fetchDbPatients, 3500);
    return () => clearInterval(interval);
  }, []);

  // Sync Prescription to Common SQLite Database
  const syncPrescriptionToDb = async () => {
    try {
      const payload = {
        patient_id: patient.dbId || patient.id || "P-101",
        diagnosis: diagnosis,
        doctor_notes: doctorNotes,
        medications: medicines,
        doctor_name: "Dr. Aarav",
        doctor_reg: "MCI-2018-847291"
      };

      const res = await fetch('/api/prescriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const d = await res.json();
        showToast(`E-Prescription ${d.prescription_token} saved to Common Database! Patient Kiosk updated.`);
        fetchDbPatients();
      } else {
        showToast("E-Prescription successfully signed and synced to ABDM!");
      }
    } catch (e) {
      showToast("E-Prescription successfully signed and synced to ABDM!");
    }
  };

  // Sync 108 Emergency Referral to Common SQLite Database
  const syncReferralToDb = async () => {
    try {
      const payload = {
        patient_id: patient.dbId || patient.id || "P-101",
        receiving_facility: "District Civil Hospital & Trauma Centre, Wardha",
        reason: "Severe clinical complication requiring emergency tertiary care",
        checklist: ["IV Cannulation (18G)", "Normal Saline Bolus", "O2 Support"]
      };

      await fetch('/api/referrals/108', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      showToast("108 ALS Ambulance Referral recorded in Common Database & District Hospital notified!");
      fetchDbPatients();
    } catch (e) {
      showToast("108 ALS Ambulance dispatched. District hospital notified!");
    }
  };


  // Left Column Tabs: 'triage' (ASHA Triage) or 'ocr' (Previous OCR Records)
  const [leftTab, setLeftTab] = useState('triage');

  // Modals & UI States
  const [isQueueDrawerOpen, setIsQueueDrawerOpen] = useState(false);
  const [queueSearch, setQueueSearch] = useState("");
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isAddMedModalOpen, setIsAddMedModalOpen] = useState(false);
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
  const [isReferralModalOpen, setIsReferralModalOpen] = useState(false);
  // Login & Portal Switcher State (ASHA / Patient Kiosk Integration)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [loginTab, setLoginTab] = useState('roles'); // 'roles' or 'auth'
  const [selectedRole, setSelectedRole] = useState('doctor'); // 'doctor', 'asha', 'patient', 'pharmacist'
  const [loginMobile, setLoginMobile] = useState('9876543210');
  const [loginOtp, setLoginOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);

  const [referralDispatched, setReferralDispatched] = useState(false);
  const [selectedOcrDoc, setSelectedOcrDoc] = useState(null);
  const [copiedAbha, setCopiedAbha] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  // Sync / Cloud Edge State
  const [isEdgeOffline, setIsEdgeOffline] = useState(false);
  const [pendingSyncCount, setPendingSyncCount] = useState(2);
  const [isSyncing, setIsSyncing] = useState(false);

  // Audio Playback Simulation State
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const audioTimerRef = useRef(null);

  // Selected AI Tag
  const [selectedTag, setSelectedTag] = useState(null);

  // New Medication Form State
  const [newMedName, setNewMedName] = useState("");
  const [newMedDosage, setNewMedDosage] = useState("1 Tab, BD, 5 Days");
  const [newMedInstructions, setNewMedInstructions] = useState("After meals with water");
  const [contraindicationWarning, setContraindicationWarning] = useState("");

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  const handleSyncGateway = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setPendingSyncCount(0);
      showToast("✓ All local OPD records synced to ABDM Gateway & District NIC Cloud!");
    }, 1200);
  };

  const togglePlayAudio = () => {
    if (isPlayingAudio) {
      clearInterval(audioTimerRef.current);
      setIsPlayingAudio(false);
      showToast("Audio playback paused");
    } else {
      setIsPlayingAudio(true);
      showToast(`Playing ASHA audio dispatch (${patient.name})...`);
      
      try {
        if ('speechSynthesis' in window && window.speechSynthesis) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(patient.voiceNote.hindi);
          utterance.lang = "hi-IN";
          utterance.rate = 0.95;
          window.speechSynthesis.speak(utterance);
        }
      } catch (err) {}

      audioTimerRef.current = setInterval(() => {
        setAudioProgress((prev) => {
          if (prev >= 100) {
            clearInterval(audioTimerRef.current);
            setIsPlayingAudio(false);
            return 0;
          }
          return prev + 5;
        });
      }, 400);
    }
  };

  useEffect(() => {
    return () => {
      if (audioTimerRef.current) clearInterval(audioTimerRef.current);
      if ('speechSynthesis' in window && window.speechSynthesis) window.speechSynthesis.cancel();
    };
  }, []);

  const handleDeleteMed = (id, name) => {
    setMedicines(prev => prev.filter(m => m.id !== id));
    showToast(`Removed "${name}" from prescription`);
  };

  const handleMedNameChange = (name) => {
    setNewMedName(name);
    const lower = name.toLowerCase();
    if (
      lower.includes("sulfa") || 
      lower.includes("pyrimethamine") || 
      lower.includes("bactrim") || 
      lower.includes("septran") || 
      lower.includes("cotrimoxazole")
    ) {
      setContraindicationWarning("CRITICAL CDSS SAFETY LOCK: Sulfa-derivative detected! Patient Rajesh Kumar has documented hypersensitivity/anaphylaxis history to Sulfa-class drugs.");
    } else {
      setContraindicationWarning("");
    }
  };

  const handleAddMedication = (e) => {
    e.preventDefault();
    if (!newMedName.trim()) return;

    if (contraindicationWarning) {
      alert("Cannot prescribe this medication: Blocked by CDSS Safety Protocol for Sulfa allergy.");
      return;
    }

    const newMed = {
      id: Date.now(),
      name: newMedName.trim(),
      dosage: newMedDosage,
      instructions: newMedInstructions,
      type: "Clinical Prescription"
    };

    setMedicines(prev => [...prev, newMed]);
    setIsAddMedModalOpen(false);
    setNewMedName("");
    setContraindicationWarning("");
    showToast(`Added "${newMed.name}" to prescription pad`);
  };

  const handleCopyAbha = () => {
    navigator.clipboard?.writeText(patient.abhaId);
    setCopiedAbha(true);
    showToast(`ABHA ID copied: ${patient.abhaId}`);
    setTimeout(() => setCopiedAbha(false), 2500);
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 font-sans flex flex-col antialiased selection:bg-teal-500 selection:text-white">

      {/* ========================================================================= */}
      {/* 1. TOP NAVBAR (Sticky, bg-white, border-b)                               */}
      {/* ========================================================================= */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Left: Logo & Subtitle */}
            <div className="flex items-center space-x-3.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-700 via-teal-600 to-emerald-500 flex items-center justify-center text-white shadow-sm ring-2 ring-teal-600/20">
                <Icon name="stethoscope" className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center space-x-2">
                  <span className="text-xl font-bold tracking-tight text-teal-700">
                    MediApp
                  </span>
                  <span className="text-[10px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200/80">
                    PHC Cloud
                  </span>
                </div>
                <span className="text-xs font-medium text-slate-500">
                  Rural Health AI - PS 133
                </span>
              </div>
            </div>

            {/* Center: Status badges using flexbox */}
            <div className="hidden md:flex items-center space-x-2.5">
              
              {/* Badge 1: PHC Unit #04 with green pulse dot */}
              <div className="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="font-semibold text-slate-800">PHC Unit #04</span>
              </div>

              {/* Badge 2: Queue: 14/42 (Interactive Click opens Patient Queue Switcher) */}
              <button
                type="button"
                onClick={() => setIsQueueDrawerOpen(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs transition-colors cursor-pointer"
                title="Click to view full triage queue & switch patients"
              >
                <Icon name="users" className="w-3.5 h-3.5 text-teal-600" />
                <span>Queue:</span>
                <span className="font-bold text-slate-900">14/42</span>
                <span className="text-[10px] bg-teal-100 text-teal-800 px-1 rounded ml-1">Switch</span>
              </button>

              {/* Badge 3: ABDM Gateway Connected (Interactive Sync Trigger) */}
              <button
                type="button"
                onClick={handleSyncGateway}
                disabled={isSyncing}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-xs font-medium text-emerald-800 shadow-2xs transition-colors cursor-pointer"
                title="Click to sync local records with National ABDM gateway"
              >
                <span className={isSyncing ? "animate-spin" : ""}>
                  <Icon name={isSyncing ? "refreshCw" : "shieldCheck"} className="w-3.5 h-3.5 text-emerald-600" />
                </span>
                <span className="font-semibold">
                  {isSyncing ? "Syncing ABDM..." : "ABDM Gateway Connected"}
                </span>
                {pendingSyncCount > 0 && !isSyncing && (
                  <span className="w-2 h-2 rounded-full bg-amber-500" title="2 records queued for cloud sync"></span>
                )}
              </button>
            </div>

            {/* Right: ASHA / Patient Dashboard Icon Link, Profile Avatar & Scan ASHA QR Button */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              
              {/* Direct ASHA / Patient Dashboard Link with Icon */}
              <a
                href="/kiosk"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100/90 border border-teal-300 text-teal-900 text-xs sm:text-sm font-bold shadow-2xs hover:shadow-xs transition-all duration-150 cursor-pointer group"
                title="Click to open ASHA / Patient Dashboard (https://medikiosk-topaz-mu.vercel.app)"
              >
                <div className="w-6 h-6 rounded-md bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                  <Icon name="users" className="w-3.5 h-3.5" />
                </div>
                <span className="font-bold tracking-tight">ASHA / Patient Dashboard</span>
                <Icon name="externalLink" className="w-3.5 h-3.5 text-teal-700 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>

              {/* Doctor Avatar */}
              <div className="flex items-center space-x-2 pl-1">
                <div className="relative">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-slate-700 to-slate-900 text-white font-medium text-xs sm:text-sm flex items-center justify-center ring-2 ring-slate-200 shadow-xs">
                    DA
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full"></span>
                </div>
                <div className="hidden xl:flex flex-col text-left">
                  <span className="text-xs sm:text-sm font-semibold text-slate-800 leading-tight">Dr. Aarav</span>
                  <span className="text-[10px] sm:text-[11px] text-slate-500">Medical Officer</span>
                </div>
              </div>

              {/* Scan ASHA QR Button */}
              <button
                type="button"
                onClick={() => setIsQrModalOpen(true)}
                className="inline-flex items-center space-x-1.5 px-2.5 py-1.5 sm:px-3.5 sm:py-2 rounded-lg bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white text-xs sm:text-sm font-medium shadow-sm hover:shadow-md transition-all duration-150 cursor-pointer focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
              >
                <Icon name="qrcode" className="w-4 h-4" />
                <span className="font-medium hidden sm:inline">Scan ASHA QR</span>
                <span className="font-medium sm:hidden">Scan QR</span>
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-5">
        
        {/* ========================================================================= */}
        {/* 2. PATIENT INFO & VITALS HEADER (bg-slate-50, shadow-sm, rounded-md)      */}
        {/* ========================================================================= */}
        <section className="bg-slate-50 border border-slate-200/90 shadow-sm rounded-md p-4 sm:p-5 transition-all">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            
            {/* Left: Patient Name, ABHA ID & Flashing Priority 1 (Urgent) Badge */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                  {patient.name}, {patient.age} / {patient.gender}
                </h1>

                {/* Flashing/animated red badge "Priority 1 (Urgent)" */}
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-rose-100 border border-rose-300 text-rose-800 text-xs font-semibold shadow-2xs">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-90"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
                  </span>
                  <span className="animate-pulse tracking-wide uppercase text-[11px]">
                    {patient.priority}
                  </span>
                </div>
              </div>

              {/* ABHA ID & Quick Links */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                <div className="flex items-center space-x-1.5 bg-white px-2 py-0.5 rounded border border-slate-200">
                  <span className="font-medium text-slate-600">ABHA ID:</span>
                  <code className="font-mono font-semibold text-slate-800">{patient.abhaId}</code>
                  <button 
                    onClick={handleCopyAbha} 
                    className="text-slate-400 hover:text-teal-700 transition-colors p-0.5 rounded focus:outline-none cursor-pointer"
                    title="Copy ABHA ID"
                  >
                    <Icon name={copiedAbha ? "check" : "copy"} className="w-3.5 h-3.5 text-teal-600" />
                  </button>
                </div>
                <div className="flex items-center space-x-1 text-slate-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                  <span>OPD Token: <strong className="text-slate-700">#{patient.id}</strong></span>
                </div>
                <div className="flex items-center space-x-1 text-slate-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                  <span>ASHA Facilitator: <strong className="text-slate-700">{patient.ashaWorker}</strong></span>
                </div>
                <div className="flex items-center space-x-1 text-slate-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                  <button 
                    onClick={() => setLeftTab('ocr')}
                    className="text-teal-700 font-semibold underline hover:text-teal-900 cursor-pointer"
                  >
                    3 Historical OCR Records Linked
                  </button>
                </div>
              </div>
            </div>

            {/* Right: Vitals Grid (4 separate stat cards) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 lg:w-auto">
              
              {/* BP: 90/60 mmHg (red for low BP) */}
              <div className="bg-white p-3 rounded-lg border border-rose-200 shadow-2xs flex flex-col justify-between min-w-[125px]">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-slate-600 uppercase tracking-wider text-[10px]">Blood Pressure</span>
                  <Icon name="heartPulse" className="w-3.5 h-3.5 text-rose-500" />
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className={`text-xl sm:text-2xl font-extrabold ${patient.vitals.bpAlertColor} tracking-tight`}>
                    {patient.vitals.bp}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">{patient.vitals.bpUnit}</span>
                </div>
                <div className="mt-1 flex items-center space-x-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                  <span className="text-[10px] font-bold text-rose-600 uppercase tracking-tight">{patient.vitals.bpAlert}</span>
                </div>
              </div>

              {/* Pulse: 108 bpm */}
              <div className="bg-white p-3 rounded-lg border border-amber-200 shadow-2xs flex flex-col justify-between min-w-[125px]">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-slate-600 uppercase tracking-wider text-[10px]">Pulse Rate</span>
                  <Icon name="activity" className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-extrabold text-slate-800 tracking-tight">
                    {patient.vitals.pulse}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">bpm</span>
                </div>
                <div className="mt-1 flex items-center space-x-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                  <span className="text-[10px] font-semibold text-amber-700">{patient.vitals.pulseAlert}</span>
                </div>
              </div>

              {/* SpO2: 94% */}
              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs flex flex-col justify-between min-w-[125px]">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-slate-600 uppercase tracking-wider text-[10px]">SpO2 Saturation</span>
                  <Icon name="wind" className="w-3.5 h-3.5 text-teal-600" />
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-extrabold text-slate-800 tracking-tight">
                    {patient.vitals.spo2}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">%</span>
                </div>
                <div className="mt-1 flex items-center space-x-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  <span className="text-[10px] font-semibold text-slate-600">{patient.vitals.spo2Alert}</span>
                </div>
              </div>

              {/* Temp: 104.2°F (red for high fever) */}
              <div className="bg-white p-3 rounded-lg border border-rose-200 shadow-2xs flex flex-col justify-between min-w-[125px]">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-slate-600 uppercase tracking-wider text-[10px]">Body Temp</span>
                  <Icon name="thermometer" className="w-3.5 h-3.5 text-rose-500" />
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className={`text-xl sm:text-2xl font-extrabold ${patient.vitals.tempAlertColor} tracking-tight`}>
                    {patient.vitals.temp}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">°F</span>
                </div>
                <div className="mt-1 flex items-center space-x-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>
                  <span className="text-[10px] font-bold text-rose-600 uppercase tracking-tight">{patient.vitals.tempAlert}</span>
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* 3. MAIN CONTENT (CSS Grid: grid-cols-2 with gap-6)                        */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* ----------------------------------------------------------------------- */}
          {/* LEFT COLUMN: "AI Patient History (Triaged by ASHA)" & OCR RECORDS       */}
          {/* ----------------------------------------------------------------------- */}
          <div className="space-y-4">
            
            {/* Left Column Header with Navigation Tabs */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setLeftTab('triage')}
                  className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                    leftTab === 'triage'
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  <Icon name="sparkles" className="w-3.5 h-3.5" />
                  <span>AI Patient History (ASHA)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLeftTab('ocr')}
                  className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                    leftTab === 'ocr'
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  <Icon name="history" className="w-3.5 h-3.5" />
                  <span>Previous OCR Records ({OCR_RECORDS_DATA.length})</span>
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse ml-1"></span>
                </button>
              </div>

              <span className="text-[11px] text-slate-500 hidden sm:inline">
                {leftTab === 'triage' ? 'ASHA Live Telemetry' : 'ABDM Health Locker Vault'}
              </span>
            </div>

            {/* TAB 1: AI PATIENT HISTORY (TRIAGED BY ASHA) */}
            {leftTab === 'triage' && (
              <div className="space-y-4 animate-fadeIn">
                
                {/* Allergy Banner linking directly to OCR */}
                <div className="bg-red-50 border border-red-300 rounded-lg p-2.5 flex items-center justify-between text-xs text-red-900 shadow-2xs">
                  <div className="flex items-center space-x-2">
                    <Icon name="alertTriangle" className="w-4 h-4 text-red-600 shrink-0" />
                    <span>
                      <strong>Past OCR Flag:</strong> Patient has severe allergy to Sulfa drugs (Civil Hosp Oct 2024).
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setLeftTab('ocr');
                      setSelectedOcrDoc(OCR_RECORDS_DATA[0]);
                    }}
                    className="text-xs font-bold text-red-800 underline hover:text-red-950 cursor-pointer ml-2 shrink-0"
                  >
                    View OCR Slip &rarr;
                  </button>
                </div>

                {/* Chief Complaint Card: Red tinted background (bg-rose-50, border-rose-200) */}
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                      <span className="text-xs font-bold text-rose-900 uppercase tracking-wider">
                        Chief Complaint
                      </span>
                    </div>
                    <span className="text-[11px] font-semibold text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded border border-rose-200">
                      Critical Symptom
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-rose-950 leading-relaxed">
                    {patient.chiefComplaint}
                  </p>
                  <div className="mt-2.5 pt-2 border-t border-rose-200/60 flex items-center justify-between text-xs text-rose-800/80">
                    <span>Onset: 72 hrs ago</span>
                    <span>Rigors: Present with sweating</span>
                  </div>
                </div>

                {/* HPI Card: White bg */}
                <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        History of Present Illness (HPI)
                      </span>
                    </div>
                    <span className="text-[11px] font-medium text-slate-500">
                      Automated Extraction
                    </span>
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed font-normal">
                    {patient.hpi}
                  </p>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                      <span className="block text-[10px] text-slate-400 uppercase">Hydration</span>
                      <span className="font-semibold text-slate-700">Dry Mucosa</span>
                    </div>
                    <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                      <span className="block text-[10px] text-slate-400 uppercase">Nausea/Emesis</span>
                      <span className="font-semibold text-slate-700">3-4 Episodes</span>
                    </div>
                    <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                      <span className="block text-[10px] text-slate-400 uppercase">Ambulation</span>
                      <span className="font-semibold text-slate-700">Needs Support</span>
                    </div>
                  </div>
                </div>

                {/* ASHA Voice Transcript Card: Light gray bg. Play Audio icon button. Italic text. */}
                <div className="bg-slate-100 border border-slate-200/90 rounded-lg p-4 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Icon name="volume2" className="w-4 h-4 text-slate-600" />
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        ASHA Voice Transcript
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={togglePlayAudio}
                      className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-all duration-150 cursor-pointer shadow-2xs ${
                        isPlayingAudio
                          ? "bg-rose-600 hover:bg-rose-700 text-white animate-pulse"
                          : "bg-teal-700 hover:bg-teal-800 text-white"
                      }`}
                    >
                      <Icon name={isPlayingAudio ? "pause" : "play"} className="w-3.5 h-3.5" />
                      <span>{isPlayingAudio ? "Pause" : "Play Audio"}</span>
                    </button>
                  </div>

                  {isPlayingAudio && (
                    <div className="bg-white p-2 rounded border border-slate-200 space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                        <span className="text-teal-700 font-semibold flex items-center space-x-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-ping"></span>
                          <span>{patient.voiceNote.audioFile}</span>
                        </span>
                        <span>{Math.floor(audioProgress * 0.14)}s / {patient.voiceNote.duration}</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div 
                          className="bg-teal-600 h-full transition-all duration-300"
                          style={{ width: `${audioProgress}%` }}
                        ></div>
                      </div>
                      <div className="flex items-center justify-center space-x-1 h-4 pt-1">
                        {[40, 75, 90, 60, 100, 45, 80, 95, 70, 30, 85, 60, 90, 50].map((h, i) => (
                          <span
                            key={i}
                            className="w-1 bg-teal-500 rounded-full animate-pulse"
                            style={{ height: `${h}%`, animationDelay: `${i * 70}ms` }}
                          ></span>
                        ))}
                      </div>
                    </div>
                  )}

                  <blockquote className="border-l-2 border-teal-500 pl-3 py-1">
                    <p className="text-sm text-slate-700 italic font-medium leading-relaxed">
                      "{patient.voiceNote.hindi}"
                    </p>
                    <p className="text-xs text-slate-500 italic mt-1 font-normal">
                      Translation: "{patient.voiceNote.english}"
                    </p>
                  </blockquote>
                </div>

                {/* AI Tags: Render 3 interactive pill-shaped tags: "#MalariaSuspect", "#HighFever", "#ASHA_Referred" (bg-teal-100, text-teal-800) */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold uppercase text-[11px] tracking-wider text-slate-600">
                      AI Clinical Diagnostic Tags
                    </span>
                    <span className="text-[11px] text-teal-700">Click tag to inspect inference</span>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2">
                    {patient.tags.map((tag) => {
                      const isSelected = selectedTag === tag;
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            const next = isSelected ? null : tag;
                            setSelectedTag(next);
                            if (next) showToast(`Selected tag ${tag} for clinical reasoning`);
                          }}
                          className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold cursor-pointer transition-all duration-150 shadow-2xs border ${
                            isSelected 
                              ? "bg-teal-700 text-white border-teal-800 ring-2 ring-teal-500/30 scale-105" 
                              : "bg-teal-100 text-teal-800 border-teal-200/80 hover:bg-teal-200/80 hover:border-teal-300"
                          }`}
                        >
                          <span>{tag}</span>
                          {isSelected && <Icon name="check" className="w-3 h-3 text-white ml-0.5" />}
                        </button>
                      );
                    })}
                  </div>

                  {selectedTag && (
                    <div className="mt-2 p-2.5 rounded-md bg-teal-50/80 border border-teal-200 text-xs text-teal-900 flex items-start space-x-2 animate-fadeIn">
                      <Icon name="sparkles" className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">{selectedTag} Inference Protocol: </span>
                        <span>
                          {selectedTag === "#MalariaSuspect" && "Rapid Diagnostic Test (RDT) card advised before ACT administration. High seasonal vector transmission reported in Zone 4."}
                          {selectedTag === "#HighFever" && "Temp 104.2°F with BP 90/60 mmHg indicates risk of septic or tropical febrile shock. Start oral or IV rehydration."}
                          {selectedTag === "#ASHA_Referred" && "Sub-centre pre-referral administered 1 Paracetamol 500mg at 09:30 AM. Blood slide prepared."}
                          {selectedTag !== "#MalariaSuspect" && selectedTag !== "#HighFever" && selectedTag !== "#ASHA_Referred" && "Clinical rule verified against NVBDCP protocol guidelines."}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Section Footer */}
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center space-x-2">
                    <Icon name="history" className="w-4 h-4 text-teal-600" />
                    <span>
                      <strong>Previous Records:</strong> 3 Scanned OCR documents available in patient vault.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setLeftTab('ocr')}
                    className="text-xs font-semibold text-teal-700 hover:text-teal-800 underline cursor-pointer"
                  >
                    Open OCR Vault &rarr;
                  </button>
                </div>

              </div>
            )}

            {/* TAB 2: PREVIOUS OCR RECORDS (ARCHIVE) */}
            {leftTab === 'ocr' && (
              <div className="space-y-3 animate-fadeIn">
                <div className="bg-teal-50 border border-teal-200 p-3 rounded-lg text-xs text-teal-900 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Icon name="fileCheck" className="w-4 h-4 text-teal-700" />
                    <span>
                      <strong>ABDM Digitized Vault:</strong> Historical hospital discharges & lab reports scanned via Optical Character Recognition (OCR).
                    </span>
                  </div>
                  <span className="font-mono text-[10px] font-bold bg-white px-2 py-0.5 rounded border border-teal-300">
                    3 DOCUMENTS
                  </span>
                </div>

                {/* Render OCR Record Cards */}
                {OCR_RECORDS_DATA.map((doc, idx) => (
                  <div
                    key={doc.id}
                    className={`p-4 rounded-lg border transition-all shadow-2xs ${
                      doc.severity === "CRITICAL"
                        ? "bg-rose-50/70 border-rose-300 hover:border-rose-400"
                        : "bg-white border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">
                            {idx + 1}. {doc.title}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${doc.badgeColor}`}>
                            {doc.badge}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          {doc.facility} • <strong className="text-slate-700">{doc.date}</strong>
                        </p>
                      </div>

                      <span className="text-[11px] font-mono font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 shrink-0">
                        OCR: {doc.confidence}
                      </span>
                    </div>

                    <div className="mt-2.5 p-2.5 rounded bg-white border border-slate-200/90 text-xs">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                        Key Medical Extraction:
                      </span>
                      <p className={`font-medium ${doc.severity === 'CRITICAL' ? 'text-red-900 font-bold' : 'text-slate-800'}`}>
                        {doc.finding}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-1 text-slate-500">
                        <span className="text-[11px]">Keywords:</span>
                        {doc.keyHighlights.map(kh => (
                          <span key={kh} className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-mono">
                            {kh}
                          </span>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() => setSelectedOcrDoc(doc)}
                        className="font-bold text-teal-700 hover:text-teal-900 flex items-center space-x-1 cursor-pointer"
                      >
                        <Icon name="zoomIn" className="w-3.5 h-3.5" />
                        <span>Inspect Scanned Document</span>
                      </button>
                    </div>
                  </div>
                ))}

                <button
                  type="button"
                  onClick={() => setLeftTab('triage')}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
                >
                  &larr; Return to Frontline ASHA Triage
                </button>
              </div>
            )}

          </div>

          {/* ----------------------------------------------------------------------- */}
          {/* RIGHT COLUMN: "Digital Prescription Pad"                                */}
          {/* ----------------------------------------------------------------------- */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs flex flex-col justify-between space-y-4">
            
            <div className="space-y-4">
              
              {/* Prescription Pad Header */}
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                    <Icon name="pill" className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                      Digital Prescription Pad
                    </h2>
                    <span className="text-xs text-slate-500">
                      PHC OPD e-Rx #{patient.id} • Ayushman Bharat Digital Mission (ABDM)
                    </span>
                  </div>
                </div>

                <div className="text-right hidden sm:block">
                  <span className="text-[11px] font-mono text-slate-500 block">Date: 24 Sep 2026</span>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Live Session
                  </span>
                </div>
              </div>

              {/* Diagnosis Input: A real, typeable <input> or <textarea> field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="diagnosis-input-box" className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Provisional Clinical Diagnosis <span className="text-rose-500">*</span>
                  </label>
                  <span className="text-[11px] text-slate-400">ICD-10 / SNOMED CT Mapped</span>
                </div>
                
                <div className="relative">
                  <input
                    id="diagnosis-input-box"
                    type="text"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    placeholder="Enter confirmed or provisional diagnosis..."
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:border-teal-600 focus:ring-2 focus:ring-teal-500/20 text-slate-900 text-sm font-semibold transition-all shadow-2xs bg-white placeholder-slate-400"
                  />
                  <div className="absolute right-3 top-2.5 text-xs text-teal-700 bg-teal-50 border border-teal-200 px-2 py-0.5 rounded font-mono font-medium">
                    ICD-10: B54
                  </div>
                </div>

                {/* Quick suggestions pills */}
                <div className="flex items-center space-x-1.5 text-xs text-slate-500 pt-1">
                  <span className="text-[11px] text-slate-400">Suggestions:</span>
                  {[
                    "Plasmodium Vivax Malaria",
                    "Falciparum Malaria (Severe)",
                    "Acute Febrile Illness"
                  ].map((sug) => (
                    <button
                      key={sug}
                      type="button"
                      onClick={() => setDiagnosis(sug)}
                      className="text-[11px] text-slate-600 hover:text-teal-700 bg-slate-100 hover:bg-teal-50 border border-slate-200 px-2 py-0.5 rounded cursor-pointer transition-colors"
                    >
                      +{sug}
                    </button>
                  ))}
                </div>
              </div>

              {/* Medication List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1.5">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Rx Medication Regimen ({medicines.length})
                    </span>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                      PHC Essential Drug List
                    </span>
                  </div>
                  
                  {/* "+ Add Medication" outline button */}
                  <button
                    type="button"
                    onClick={() => setIsAddMedModalOpen(true)}
                    className="inline-flex items-center space-x-1 px-3 py-1 rounded-md border border-teal-600 text-teal-700 hover:bg-teal-50 active:bg-teal-100 text-xs font-semibold transition-all duration-150 cursor-pointer shadow-2xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <Icon name="plus" className="w-3.5 h-3.5" />
                    <span>+ Add Medication</span>
                  </button>
                </div>

                {/* Medication Cards List */}
                <div className="space-y-2.5">
                  {medicines.length === 0 ? (
                    <div className="text-center py-6 border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-xs">
                      No medicines prescribed yet. Click "+ Add Medication" above.
                    </div>
                  ) : (
                    medicines.map((med, index) => (
                      <div
                        key={med.id}
                        className="group flex items-center justify-between p-3 rounded-lg border border-slate-200 bg-slate-50/60 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-2xs"
                      >
                        <div className="flex items-start space-x-3">
                          <div className="w-7 h-7 rounded-md bg-white border border-slate-200 flex items-center justify-center font-bold text-xs text-teal-700 shadow-2xs shrink-0 mt-0.5">
                            {index + 1}
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h4 className="text-sm font-bold text-slate-900">
                                {med.name}
                              </h4>
                              {med.type && (
                                <span className="text-[10px] font-medium bg-slate-200/70 text-slate-700 px-1.5 py-0.5 rounded">
                                  {med.type}
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 mt-1">
                              <span className="font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200/70">
                                Dosage: {med.dosage}
                              </span>
                              {med.instructions && (
                                <span className="text-slate-500 text-[11px]">
                                  {med.instructions}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Delete trash icon button */}
                        <button
                          type="button"
                          onClick={() => handleDeleteMed(med.id, med.name)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                          title={`Delete ${med.name}`}
                        >
                          <Icon name="trash2" className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Physician Examination & Handover Notes */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Physician Handover & Observation Notes
                </label>
                <textarea
                  rows={2}
                  value={doctorNotes}
                  onChange={(e) => setDoctorNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-teal-600 text-slate-800 text-xs font-medium leading-relaxed bg-white"
                  placeholder="Enter clinical handover notes..."
                ></textarea>
              </div>

              {/* CDSS Alert Box: Prominent alert component at bottom (bg-red-50, border-red-500, text-red-700). Icon: AlertTriangle */}
              <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg shadow-2xs text-red-700 space-y-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <Icon name="alertTriangle" className="w-5 h-5 text-red-600 shrink-0" />
                    <h3 className="text-sm font-bold tracking-tight text-red-800 uppercase">
                      {patient.cdss.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-red-100 text-red-800 px-2 py-0.5 rounded border border-red-200">
                    SAFETY LOCK
                  </span>
                </div>

                <p className="text-xs font-semibold text-red-700 leading-relaxed pl-7">
                  {patient.cdss.description}
                </p>

                <div className="pl-7 pt-1 flex items-center justify-between text-xs text-red-800/90">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                    <span className="text-[11px]">Flagged from: <strong>Civil Hospital Discharge Slip (2024 OCR)</strong></span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedOcrDoc(OCR_RECORDS_DATA[0])}
                    className="text-[11px] font-bold underline hover:text-red-900 cursor-pointer bg-red-100/60 px-2 py-0.5 rounded border border-red-200"
                  >
                    View OCR Evidence Slip &rarr;
                  </button>
                </div>
              </div>

            </div>

            {/* Bottom Actions: Escalate 108 SOS & Generate E-Prescription */}
            <div className="pt-2 space-y-2.5">
              
              {/* Emergency 108 SOS Referral Button (High clinical value from Nidaan) */}
              <button
                type="button"
                onClick={() => setIsReferralModalOpen(true)}
                className="w-full py-2.5 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Icon name="ambulance" className="w-4 h-4 animate-pulse" />
                <span>🚨 Escalate & Refer to District Hospital (108 SOS Ambulance)</span>
              </button>

              {/* Action Button: Large, full-width "Generate E-Prescription" button at very bottom (bg-teal-600 hover:bg-teal-700) */}
              <button
                type="button"
                onClick={() => setIsPrescriptionModalOpen(true)}
                className="w-full py-3.5 px-4 rounded-lg bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm sm:text-base shadow-md hover:shadow-lg transition-all duration-150 cursor-pointer flex items-center justify-center space-x-2.5 focus:outline-none focus:ring-4 focus:ring-teal-500/30"
              >
                <Icon name="fileCheck" className="w-5 h-5 text-teal-100" />
                <span>Generate E-Prescription</span>
                <span className="text-xs font-normal text-teal-100 bg-teal-700/80 px-2 py-0.5 rounded ml-1">
                  ABDM Sign & Push
                </span>
              </button>
              <p className="text-center text-[11px] text-slate-400">
                Directly registers to Ayushman Bharat Digital Mission (ABDM) Care Context & sends SMS to {patient.name}
              </p>
            </div>

          </div>

        </div>

      </main>

      {/* ========================================================================= */}
      {/* BOTTOM FOOTER / PORTAL STATUS & DIRECT ASHA/PATIENT LINK                   */}
      {/* ========================================================================= */}
      <footer className="w-full bg-white border-t border-slate-200 mt-10 py-3.5 px-4 sm:px-6 lg:px-8 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2 text-slate-500 text-center sm:text-left">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-bold text-slate-800">MediApp Rural Health Suite</span>
            <span className="text-slate-300 hidden sm:inline">•</span>
            <span>Current Console: <strong>Doctor OPD (PHC Unit #04)</strong></span>
            <span className="text-slate-300 hidden sm:inline">•</span>
            <span className="text-slate-500">Dr. Aarav (MD)</span>
          </div>

          <div className="flex items-center space-x-2.5">
            <span className="text-slate-400 hidden md:inline text-[11px]">Field Intake Kiosk:</span>
            <button
              type="button"
              onClick={() => setIsLoginModalOpen(true)}
              className="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium transition-colors cursor-pointer"
            >
              <Icon name="logIn" className="w-3.5 h-3.5 text-slate-500" />
              <span>Switch Login</span>
            </button>

            {/* Direct Option ASHA / Patient that opens medikiosk-topaz-mu.vercel.app */}
            <a
              href="/kiosk"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => showToast("Opening ASHA / Patient Kiosk (medikiosk-topaz-mu.vercel.app)...")}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold shadow-xs hover:shadow transition-all cursor-pointer group"
              title="Click to open https://medikiosk-topaz-mu.vercel.app"
            >
              <span>ASHA / Patient Dashboard</span>
              <Icon name="externalLink" className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </div>
      </footer>


      {/* ========================================================================= */}
      {/* DRAWER: PATIENT TRIAGE QUEUE SWITCHER                                    */}
      {/* ========================================================================= */}
      {isQueueDrawerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fadeIn">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200">
            
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Icon name="users" className="w-5 h-5 text-teal-700" />
                <h3 className="font-bold text-slate-900 text-sm">PHC Unit #04 Triage Queue</h3>
              </div>
              <button
                onClick={() => setIsQueueDrawerOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            {/* Queue Search */}
            <div className="p-3 border-b border-slate-100 bg-white">
              <div className="relative">
                <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={queueSearch}
                  onChange={(e) => setQueueSearch(e.target.value)}
                  placeholder="Search patient, village or ABHA..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-teal-600"
                />
              </div>
            </div>

            {/* Queue Patients List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
              {patientsQueue.filter(p => 
                p.name.toLowerCase().includes(queueSearch.toLowerCase()) || 
                p.village.toLowerCase().includes(queueSearch.toLowerCase()) ||
                p.abhaId.includes(queueSearch)
              ).map((p, idx) => {
                const isActive = p.id === patient.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      setCurrentPatientIndex(PATIENTS_QUEUE.findIndex(item => item.id === p.id));
                      setIsQueueDrawerOpen(false);
                      showToast(`Switched active patient to ${p.name} (#${p.id})`);
                    }}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      isActive 
                        ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-500/20 shadow-xs' 
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-sm text-slate-900">{p.name}</span>
                          <span className="text-xs text-slate-500">({p.age}, {p.gender})</span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5 line-clamp-1">{p.conditionSummary}</p>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        p.isUrgent ? 'bg-rose-100 text-rose-800 border border-rose-300' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {p.priority}
                      </span>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                      <span>{p.village}</span>
                      <span className="font-mono text-slate-600">BP: {p.vitals.bp}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
              Select any patient to switch live OPD examination pad
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EMERGENCY 108 SOS REFERRAL & AMBULANCE DISPATCH                    */}
      {/* ========================================================================= */}
      {isReferralModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-rose-300 animate-fadeIn my-6">
            
            <div className="px-6 py-4 bg-rose-600 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Icon name="ambulance" className="w-6 h-6 text-white animate-bounce" />
                <div>
                  <h3 className="text-base font-bold">108 Emergency Medical Dispatch & Fast-Track Referral</h3>
                  <p className="text-xs text-rose-100">National Health Mission • Critical Care Telemetry Handover</p>
                </div>
              </div>
              <button onClick={() => setIsReferralModalOpen(false)} className="text-rose-200 hover:text-white p-1">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-700">
              
              {/* Ambulance Status Bar */}
              <div className="bg-rose-50 border border-rose-200 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2 text-rose-900 font-bold text-sm">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
                    <span>108 ALS Ambulance Dispatched</span>
                  </div>
                  <p className="text-slate-600 text-xs mt-0.5">
                    Vehicle: <strong>#MH-33-T-1082</strong> • Pilot: Santosh (GPS Locked)
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-bold text-rose-700 bg-white px-2.5 py-1 rounded border border-rose-300">
                    ETA: ~12 Mins
                  </span>
                </div>
              </div>

              {/* Patient Transfer Dossier */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] block">
                  Patient Transfer Packet (ABDM Emergency Care Context):
                </span>
                <div className="grid grid-cols-2 gap-2 text-slate-700">
                  <div>Patient: <strong>{patient.name}</strong> ({patient.age} / {patient.gender})</div>
                  <div>ABHA ID: <strong className="font-mono">{patient.abhaId}</strong></div>
                  <div>Vitals: <strong className="text-rose-600">BP {patient.vitals.bp}, Temp {patient.vitals.temp}°F</strong></div>
                  <div>Diagnosis: <strong>{diagnosis}</strong></div>
                </div>
              </div>

              {/* In-Transit Stabilization Protocol */}
              <div className="border border-slate-200 p-3 rounded-lg bg-white space-y-1.5">
                <span className="font-bold text-slate-800 text-[11px] uppercase tracking-wider block">
                  In-Transit Clinical Stabilization Checklist:
                </span>
                <ul className="list-disc pl-4 space-y-1 text-slate-600">
                  <li>Initiate slow IV Normal Saline / Ringer Lactate for hypotension (90/60 mmHg).</li>
                  <li>Administer oral or IV Paracetamol 650mg for hyperpyrexia (104.2°F).</li>
                  <li className="text-red-700 font-bold">⚠️ CRITICAL: Strictly avoid Sulfa-based antimalarials or antibiotics in transit.</li>
                  <li>Continuous SpO2 & ECG lead monitoring.</li>
                </ul>
              </div>

              {/* Intimation Status */}
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-lg text-emerald-900 flex items-center space-x-2">
                <Icon name="checkCircle2" className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>District Hospital Emergency Wing Intimated:</strong> ICU bed & on-call physician alerted via ABDM FHIR referral packet.
                </span>
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsReferralModalOpen(false)}
                  className="flex-1 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold cursor-pointer"
                >
                  Return to Dashboard
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setReferralDispatched(true);
                    showToast("Emergency 108 referral dossier transmitted to District Hospital!");
                    setTimeout(() => {
                      setIsReferralModalOpen(false);
                      setReferralDispatched(false);
                    }, 1500);
                  }}
                  className="flex-1 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                >
                  {referralDispatched ? "✓ Dossier Transmitted" : "Transmit Referral Dossier"}
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: OCR HISTORICAL DOCUMENT INSPECTOR                                   */}
      {/* ========================================================================= */}
      {selectedOcrDoc && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full overflow-hidden border border-slate-300 animate-fadeIn my-6">
            
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-lg bg-teal-500/20 border border-teal-500/40 text-teal-300 flex items-center justify-center">
                  <Icon name="fileText" className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold">{selectedOcrDoc.title}</h3>
                  <p className="text-xs text-slate-400">
                    Digitized Historical Medical Record • Confidence: <span className="text-emerald-400 font-mono">{selectedOcrDoc.confidence}</span>
                  </p>
                </div>
              </div>
              <button onClick={() => setSelectedOcrDoc(null)} className="text-slate-400 hover:text-white p-1">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Facility</span>
                  <span className="font-semibold text-slate-800">{selectedOcrDoc.facility}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Document Date</span>
                  <span className="font-semibold text-slate-800">{selectedOcrDoc.date}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Record Type</span>
                  <span className="font-semibold text-slate-800">{selectedOcrDoc.category}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Security / Status</span>
                  <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded border ${selectedOcrDoc.badgeColor}`}>
                    {selectedOcrDoc.badge}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-slate-300 rounded-lg p-4 bg-amber-50/40 relative shadow-inner overflow-hidden font-serif">
                  <div className="text-[10px] text-amber-900/60 uppercase font-mono tracking-widest border-b border-amber-200 pb-1 mb-2 flex justify-between">
                    <span>SCANNED ARTIFACT #OCR-2024-88</span>
                    <span>ARCHIVE COPY</span>
                  </div>

                  <div className="space-y-2 text-xs text-slate-800">
                    <p className="font-bold text-center border-b border-amber-300 pb-1 text-slate-900 uppercase">
                      {selectedOcrDoc.facility}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      <strong>Patient:</strong> Rajesh Kumar | <strong>Age:</strong> 44 Y / M
                    </p>

                    {selectedOcrDoc.id === "ocr-doc-1" ? (
                      <div className="my-2 p-2 bg-rose-100/90 border-2 border-rose-500 rounded relative">
                        <span className="absolute -top-2.5 right-2 bg-rose-600 text-white font-mono text-[9px] px-1.5 py-0.2 rounded uppercase font-bold">
                          [OCR BOUNDING BOX #01: ALLERGY DETECTED]
                        </span>
                        <p className="font-bold text-rose-950 text-[11px] leading-tight">
                          ADR NOTE: Patient experienced severe allergic reaction to Tab. Septran (Co-trimoxazole). Developed acute facial angioedema and wheezing.
                        </p>
                        <p className="font-bold text-rose-800 text-[10px] mt-1">
                          STRICTLY AVOID ALL SULFA-BASED COMPOUNDS (SULFADOXINE-PYRIMETHAMINE, DAPSONE).
                        </p>
                      </div>
                    ) : (
                      <div className="my-2 p-2 bg-slate-100 border border-slate-300 rounded text-[11px]">
                        <p>{selectedOcrDoc.finding}</p>
                      </div>
                    )}

                    <div className="pt-2 text-[10px] text-slate-500 italic flex justify-between">
                      <span>Verified Stamp: Medical Records Dept</span>
                      <span>Sign: Dr. V. K. Mishra</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Raw OCR Extracted Text:
                    </span>
                    <pre className="bg-slate-900 text-emerald-400 font-mono p-3 rounded-lg text-[10px] leading-relaxed max-h-44 overflow-y-auto border border-slate-800 whitespace-pre-wrap">
                      {selectedOcrDoc.rawSnippet}
                    </pre>
                  </div>

                  <div className="bg-red-50 border border-red-200 p-3 rounded-lg text-xs text-red-900 space-y-1">
                    <span className="font-bold flex items-center space-x-1 text-red-800">
                      <Icon name="shieldCheck" className="w-3.5 h-3.5 text-red-600" />
                      <span>CDSS Rule Enforcement:</span>
                    </span>
                    <p className="text-[11px] text-red-800/90 leading-relaxed">
                      This OCR document triggered the CDSS safety rule. When generating the e-prescription for malaria, any regimen containing Sulfadoxine-Pyrimethamine is actively prohibited. Artemether-Lumefantrine is recommended instead.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-slate-100 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedOcrDoc(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Close Document Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ASHA QR SCANNER DIALOG                                           */}
      {/* ========================================================================= */}
      {isQrModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between px-5 py-4 bg-slate-50 border-b border-slate-200">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center">
                  <Icon name="qrcode" className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">ASHA QR & ABDM Scanner</h3>
                  <p className="text-xs text-slate-500">Scan physical OPD slip or ASHA mobile voucher</p>
                </div>
              </div>
              <button onClick={() => setIsQrModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="relative aspect-square max-w-[280px] mx-auto bg-slate-950 rounded-xl overflow-hidden flex flex-col items-center justify-center border-2 border-teal-500/50 shadow-inner">
                <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-teal-400 to-transparent shadow-lg shadow-teal-500 animate-scan-beam"></div>
                <div className="absolute top-4 left-4 w-7 h-7 border-t-2 border-l-2 border-teal-400"></div>
                <div className="absolute top-4 right-4 w-7 h-7 border-t-2 border-r-2 border-teal-400"></div>
                <div className="absolute bottom-4 left-4 w-7 h-7 border-b-2 border-l-2 border-teal-400"></div>
                <div className="absolute bottom-4 right-4 w-7 h-7 border-b-2 border-r-2 border-teal-400"></div>

                <div className="p-3 bg-white rounded-lg shadow-md opacity-90">
                  <div className="w-32 h-32 bg-slate-900 flex flex-col items-center justify-center text-white text-[9px] font-mono text-center p-2 rounded">
                    <Icon name="qrcode" className="w-16 h-16 text-teal-400 mb-1" />
                    <span>ABHA: {patient.abhaId}</span>
                    <span className="text-[7px] text-teal-300">ASHA TOKEN VERIFIED</span>
                  </div>
                </div>

                <span className="absolute bottom-2 text-[10px] text-teal-300 font-mono tracking-wider">
                  CAMERA ACTIVE: PHC-PS133-CAM01
                </span>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">ASHA Facilitator:</span>
                  <span className="font-semibold text-slate-800">{patient.ashaWorker}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sub-Centre Outpost:</span>
                  <span className="font-semibold text-slate-800">{patient.village}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Reason for Referral:</span>
                  <span className="font-semibold text-rose-700">BP ({patient.vitals.bp}) • Temp {patient.vitals.temp}°F</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsQrModalOpen(false);
                    showToast(`Synced live telemetry for ${patient.name}`);
                  }}
                  className="flex-1 py-2 px-3 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs"
                >
                  Confirm & Sync Patient Data
                </button>
                <button
                  type="button"
                  onClick={() => setIsQrModalOpen(false)}
                  className="py-2 px-3 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: ADD MEDICATION DIALOG                                            */}
      {/* ========================================================================= */}
      {isAddMedModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between px-5 py-4 bg-slate-50 border-b border-slate-200">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center">
                  <Icon name="pill" className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Add Clinical Medication</h3>
                  <p className="text-xs text-slate-500">Select standard formulation or enter custom dosage</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsAddMedModalOpen(false);
                  setContraindicationWarning("");
                }}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMedication} className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Quick Select Common PHC Drugs
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { name: "Oral Rehydration Salts (ORS) Sachet", dose: "1 Sachet in 1L water, Frequent sips" },
                    { name: "Ondansetron 4mg Tab", dose: "1 Tab, TDS before food" },
                    { name: "Doxycycline 100mg", dose: "1 Tab, BD, 7 Days" },
                    { name: "Chloroquine 250mg", dose: "4 Tabs Stat, then 2 Tabs" },
                    { name: "Sulfadoxine-Pyrimethamine (Sulfa Drug)", dose: "3 Tabs Single Dose" },
                    { name: "Vitamin C + Zinc Tab", dose: "1 Tab, OD, 10 Days" }
                  ].map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => {
                        handleMedNameChange(preset.name);
                        setNewMedDosage(preset.dose);
                      }}
                      className={`text-xs px-2.5 py-1 rounded-md border text-left transition-colors cursor-pointer ${
                        preset.name.includes("Sulfa")
                          ? "bg-rose-50 border-rose-300 text-rose-800 hover:bg-rose-100"
                          : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-teal-50 hover:border-teal-300"
                      }`}
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  Medication Name & Strength <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newMedName}
                  onChange={(e) => handleMedNameChange(e.target.value)}
                  placeholder="e.g., ORS Sachet, Ondansetron 4mg..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-teal-600 focus:ring-2 focus:ring-teal-500/20 text-slate-900 text-sm font-medium"
                />
              </div>

              {contraindicationWarning && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-400 text-rose-800 text-xs flex items-start space-x-2 animate-shake-short">
                  <Icon name="alertTriangle" className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">CDSS PRESCRIPTION PROHIBITION:</span>
                    <p className="mt-0.5">{contraindicationWarning}</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Dosage & Frequency</label>
                  <input
                    type="text"
                    value={newMedDosage}
                    onChange={(e) => setNewMedDosage(e.target.value)}
                    placeholder="e.g., 1 Tab, BD, 3 Days"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-teal-600 text-slate-900 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Instructions / Timing</label>
                  <input
                    type="text"
                    value={newMedInstructions}
                    onChange={(e) => setNewMedInstructions(e.target.value)}
                    placeholder="e.g., After meals with water"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-teal-600 text-slate-900 text-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddMedModalOpen(false);
                    setContraindicationWarning("");
                  }}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={Boolean(contraindicationWarning)}
                  className={`px-4 py-2 rounded-lg text-white font-semibold text-xs transition-colors cursor-pointer ${
                    contraindicationWarning
                      ? "bg-slate-400 cursor-not-allowed opacity-60"
                      : "bg-teal-600 hover:bg-teal-700 active:bg-teal-800"
                  }`}
                >
                  Add to Prescription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: GENERATE E-PRESCRIPTION (Official ABDM Print Slip)               */}
      {/* ========================================================================= */}
      {isPrescriptionModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-300 animate-fadeIn my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-teal-800 text-white">
              <div className="flex items-center space-x-3">
                <Icon name="fileCheck" className="w-6 h-6 text-teal-200" />
                <div>
                  <h3 className="text-base font-bold">Government of India - Primary Health Centre (PHC)</h3>
                  <p className="text-xs text-teal-200 font-medium">Ayushman Bharat Digital Mission (ABDM) • Digital Prescription</p>
                </div>
              </div>
              <button onClick={() => setIsPrescriptionModalOpen(false)} className="text-teal-200 hover:text-white p-1">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 text-slate-800 bg-white">
              <div className="border-b border-slate-300 pb-4 flex justify-between items-start">
                <div>
                  <h4 className="text-lg font-extrabold text-teal-900">PHC UNIT #04 - RAMPUR HEALTH CENTRE</h4>
                  <p className="text-xs text-slate-500">Ministry of Health & Family Welfare • Sub-District PS-133</p>
                  <p className="text-xs text-slate-500">Consultant: <strong>Dr. Aarav, MBBS, MD</strong> (Reg. No: MCI-78491)</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-slate-700 block">Rx Token: PHC-2026-{patient.id}</span>
                  <span className="text-xs text-slate-500 block">Generated: 24-Sep-2026 12:48 PM</span>
                  <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    ABDM Care Context Created
                  </span>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Patient Name</span>
                  <span className="font-bold text-slate-800 text-sm">{patient.name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Age / Gender</span>
                  <span className="font-semibold text-slate-800">{patient.age} / {patient.gender}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">ABHA Address / ID</span>
                  <span className="font-mono font-semibold text-teal-800">{patient.abhaId}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Triage Priority</span>
                  <span className="font-bold text-rose-700">{patient.priority}</span>
                </div>
              </div>

              <div className="border border-slate-200 rounded-md p-3 bg-white">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Recorded Triage Vitals:
                </span>
                <div className="flex flex-wrap gap-4 text-xs font-medium text-slate-700">
                  <span>BP: <strong className="text-rose-600">{patient.vitals.bp} mmHg</strong></span>
                  <span>Pulse: <strong className="text-amber-700">{patient.vitals.pulse} bpm</strong></span>
                  <span>SpO2: <strong className="text-slate-800">{patient.vitals.spo2}%</strong></span>
                  <span>Temp: <strong className="text-rose-600">{patient.vitals.temp}°F</strong></span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Clinical Diagnosis:
                </span>
                <p className="text-sm font-bold text-slate-900 bg-teal-50/60 border border-teal-200 p-2.5 rounded-lg">
                  {diagnosis || "Suspected Malaria / Dengue Fever"}
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Prescribed Pharmacotherapy (Rx):
                </span>
                <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden text-xs">
                  <thead className="bg-slate-100 text-slate-700 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="p-2 border-b border-slate-200">#</th>
                      <th className="p-2 border-b border-slate-200">Medicine & Strength</th>
                      <th className="p-2 border-b border-slate-200">Dosage / Frequency</th>
                      <th className="p-2 border-b border-slate-200">Special Instructions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {medicines.map((m, idx) => (
                      <tr key={m.id} className="hover:bg-slate-50">
                        <td className="p-2 font-mono font-semibold text-slate-500">{idx + 1}</td>
                        <td className="p-2 font-bold text-slate-900">{m.name}</td>
                        <td className="p-2 font-semibold text-teal-800">{m.dosage}</td>
                        <td className="p-2 text-slate-600">{m.instructions || "As directed"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-lg text-xs text-emerald-900 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Icon name="shieldCheck" className="w-4 h-4 text-emerald-600" />
                  <span>
                    <strong>CDSS Safety Endorsement:</strong> Validated against historical allergy records. Safe pharmacotherapy confirmed.
                  </span>
                </div>
                <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-emerald-300 font-bold">
                  CLEARED
                </span>
              </div>

              <div className="border-t border-slate-200 pt-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-16 h-16 bg-slate-900 text-teal-400 p-1 rounded border border-slate-300 flex items-center justify-center">
                    <Icon name="qrcode" className="w-14 h-14" />
                  </div>
                  <div className="text-[11px] text-slate-500 space-y-0.5">
                    <p className="font-mono font-semibold text-slate-700">ABDM FHIR Bundle: SHA-256 Valid</p>
                    <p>Digital Token: abdm://ps133/rx/{patient.id}</p>
                    <p className="text-emerald-700 font-medium">Dispense at PHC Pharmacy Counter #01</p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="w-32 border-b border-slate-400 pb-1 mb-1 text-center font-serif italic text-sm text-teal-800 font-bold">
                    Dr. Aarav
                  </div>
                  <p className="text-[11px] font-bold text-slate-800">Dr. Aarav, MBBS</p>
                  <p className="text-[10px] text-slate-500">Medical Officer - PHC Unit #04</p>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Patient SMS dispatch sent to registered mobile linked to ABHA.
              </span>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs flex items-center space-x-1.5 cursor-pointer shadow-2xs"
                >
                  <Icon name="printer" className="w-3.5 h-3.5" />
                  <span>Print Prescription</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsPrescriptionModalOpen(false);
                    syncPrescriptionToDb();
                  }}
                  className="px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs cursor-pointer shadow-sm"
                >
                  Done / Next Patient
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

            {/* ========================================================================= */}
      {/* MODAL: LOGIN & ROLE SWITCHER (Matches medikiosk-topaz-mu.vercel.app design) */}
      {/* ========================================================================= */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            
            {/* Modal Top Header */}
            <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
                  <Icon name="stethoscope" className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-base tracking-tight text-white">MediApp</span>
                    <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-semibold border border-teal-500/30">
                      Unified PHC Suite
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">Portal Login & Role Switcher (PS-133)</p>
                </div>
              </div>
              <button
                onClick={() => setIsLoginModalOpen(false)}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              >
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs: Role Selector vs Staff Auth */}
            <div className="flex border-b border-slate-200 bg-slate-50 px-5 pt-3">
              <button
                onClick={() => setLoginTab('roles')}
                className={`pb-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  loginTab === 'roles'
                    ? 'border-teal-600 text-teal-800'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                Fast Portal Switch (ASHA / Patient / Doctor)
              </button>
              <button
                onClick={() => setLoginTab('auth')}
                className={`pb-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  loginTab === 'auth'
                    ? 'border-teal-600 text-teal-800'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                Staff Login (ABDM / OTP)
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4">
              {loginTab === 'roles' ? (
                <>
                  <div className="text-center sm:text-left mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                      Public Health • Pre-Consultation Ecosystem
                    </span>
                    <h2 className="text-lg font-bold text-slate-900 mt-1">Select Portal or Role</h2>
                    <p className="text-xs text-slate-500">
                      Switch between doctor consultation and the field/patient pre-intake kiosk.
                    </p>
                  </div>

                  {/* 1. Doctor / Medical Officer (Active) */}
                  <div className="p-3.5 rounded-xl border-2 border-teal-600 bg-teal-50/40 relative">
                    <span className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-teal-600 text-white">
                      Current Active View
                    </span>
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0 mt-0.5">
                        <Icon name="stethoscope" className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">Doctor / Medical Officer (OPD Console)</h4>
                        <p className="text-xs text-slate-600 mt-0.5">
                          In-clinic diagnosis, CDSS contraindication alerts, vitals examination & e-prescribing desk.
                        </p>
                        <div className="flex items-center space-x-3 mt-2 text-[11px] text-slate-500">
                          <span>User: <strong>Dr. Aarav (MD)</strong></span>
                          <span>•</span>
                          <span>Desk: <strong>PHC Unit #04</strong></span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 2. THE HIGHLIGHTED FEATURE: ASHA / Patient Pre-consultation Kiosk (medikiosk-topaz-mu.vercel.app) */}
                  <div className="p-4 rounded-xl border-2 border-emerald-500 bg-gradient-to-br from-emerald-50/90 to-teal-50/40 shadow-sm relative hover:border-emerald-600 transition-all">
                    <span className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-600 text-white shadow-2xs">
                      External Kiosk Link
                    </span>
                    <div className="flex items-start space-x-3">
                      <div className="w-11 h-11 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                        <Icon name="smartphone" className="w-6 h-6" />
                      </div>
                      <div className="space-y-1.5 flex-1 pr-24 sm:pr-28">
                        <div className="flex items-center space-x-1.5">
                          <h4 className="font-bold text-slate-900 text-sm">ASHA / Patient Dashboard</h4>
                          <span className="text-[10px] bg-emerald-200 text-emerald-900 font-semibold px-1.5 py-0.2 rounded">
                            Self-Intake
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed">
                          Community pre-consultation intake kiosk for patients and ASHA workers. Allows voice recording in local languages, symptom checklist, and digital registration before consultation.
                        </p>
                        
                        <div className="p-2 rounded-lg bg-white/80 border border-emerald-200 text-[11px] text-slate-600 space-y-1">
                          <div className="flex items-center space-x-1.5 text-emerald-800 font-medium">
                            <Icon name="checkCircle2" className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Destination URL: <strong>https://medikiosk-topaz-mu.vercel.app</strong></span>
                          </div>
                          <p className="text-slate-500">
                            Data captured on this kiosk seamlessly appears in this Doctor OPD console in real-time.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3.5 pt-3 border-t border-emerald-200/60 flex items-center justify-between">
                      <span className="text-[11px] text-emerald-800 font-medium">
                        Click to open in a new tab &rarr;
                      </span>
                      <a
                        href="/kiosk"
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => {
                          showToast("Opening ASHA / Patient Kiosk (medikiosk-topaz-mu.vercel.app)...");
                          setIsLoginModalOpen(false);
                        }}
                        className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer group"
                      >
                        <span>Open ASHA / Patient Kiosk</span>
                        <Icon name="externalLink" className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </a>
                    </div>
                  </div>

                  {/* 3. Pharmacy / Dispensary Role */}
                  <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100/80 transition-colors flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                        <Icon name="pill" className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800 text-xs sm:text-sm">PHC Pharmacy & Dispensary</h4>
                        <p className="text-[11px] text-slate-500">Medicine stock verification & prescription dispensing</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        showToast("Switched to PHC Pharmacy View (Simulated)");
                        setIsLoginModalOpen(false);
                      }}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs cursor-pointer"
                    >
                      Access
                    </button>
                  </div>
                </>
              ) : (
                /* Tab 2: Staff Sign In Form */
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (selectedRole === 'asha' || selectedRole === 'patient') {
                      showToast("Redirecting to ASHA / Patient Kiosk at medikiosk-topaz-mu.vercel.app...");
                      window.open("https://medikiosk-topaz-mu.vercel.app", "_blank");
                      setIsLoginModalOpen(false);
                    } else {
                      showToast(`Authenticated as ${selectedRole.toUpperCase()}! Session active.`);
                      setIsLoginModalOpen(false);
                    }
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Select Role</label>
                    <select
                      value={selectedRole}
                      onChange={(e) => setSelectedRole(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-teal-600 bg-white"
                    >
                      <option value="doctor">Medical Officer (Dr. Aarav) - Doctor Console</option>
                      <option value="asha">ASHA Worker / Facilitator (Community Intake)</option>
                      <option value="patient">Patient Self-Check-in Kiosk</option>
                      <option value="pharmacist">PHC Pharmacist / Dispensary Officer</option>
                    </select>
                  </div>

                  {(selectedRole === 'asha' || selectedRole === 'patient') && (
                    <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-300 text-xs text-emerald-900 space-y-2">
                      <div className="flex items-center space-x-1.5 font-bold">
                        <Icon name="checkCircle2" className="w-4 h-4 text-emerald-600" />
                        <span>Dedicated ASHA / Patient Kiosk Available</span>
                      </div>
                      <p className="text-[11px] text-emerald-800">
                        Patients and ASHA facilitators use the live touch-screen portal at <strong>medikiosk-topaz-mu.vercel.app</strong>.
                      </p>
                      <a
                        href="/kiosk"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900 underline"
                      >
                        <span>Click here to launch medikiosk-topaz-mu.vercel.app directly &rarr;</span>
                      </a>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Mobile Number or ABDM Health Professional ID
                    </label>
                    <input
                      type="text"
                      value={loginMobile}
                      onChange={(e) => setLoginMobile(e.target.value)}
                      placeholder="+91 98765 43210 or dr.aarav@hpr.abdm"
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-teal-600"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-700">Security OTP</label>
                      <button
                        type="button"
                        onClick={() => {
                          setIsOtpSent(true);
                          setLoginOtp("4829");
                          showToast("Demo OTP sent: 4829");
                        }}
                        className="text-[11px] text-teal-700 font-semibold hover:underline"
                      >
                        {isOtpSent ? "Resend OTP (Code: 4829)" : "Send OTP"}
                      </button>
                    </div>
                    <input
                      type="text"
                      value={loginOtp}
                      onChange={(e) => setLoginOtp(e.target.value)}
                      placeholder="Enter 4-digit OTP (e.g. 4829)"
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-teal-600"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-[11px] text-slate-500">
                      <span>Quick Presets:</span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedRole('doctor');
                          setLoginMobile('9876543210');
                          setLoginOtp('4829');
                        }}
                        className="underline hover:text-teal-700"
                      >
                        Doctor
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedRole('asha');
                          setLoginMobile('9876500001');
                          setLoginOtp('4829');
                        }}
                        className="underline hover:text-teal-700"
                      >
                        ASHA
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-sm cursor-pointer"
                    >
                      {selectedRole === 'asha' || selectedRole === 'patient'
                        ? 'Open ASHA/Patient Kiosk ↗'
                        : 'Sign In to Console'}
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-100 border-t border-slate-200 text-center text-[11px] text-slate-500">
              National Health Authority (NHA) • Ayushman Bharat Digital Mission (ABDM) Compliant
            </div>

          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 flex items-center space-x-3 text-xs font-medium animate-fadeIn">
          <Icon name="checkCircle2" className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white ml-2 cursor-pointer">
            <Icon name="x" className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

    </div>
  );
}

// Mount React Root
const rootElement = document.getElementById("root");
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<MediAppPHCDashboard />);
}
