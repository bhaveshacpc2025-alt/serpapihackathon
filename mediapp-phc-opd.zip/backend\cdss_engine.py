"""
cdss_engine.py - Clinical Decision Support System Engine
Integrates Clinical Safety Rules, Allergy Checks, and ABDM Validation for MediApp
"""

from typing import List, Dict, Any

SULFA_DRUGS = [
    "sulfadoxine", "pyrimethamine", "sulfamethoxazole", "trimethoprim", 
    "bactrim", "septran", "cotrimoxazole", "dapsone", "sulfasalazine"
]

def evaluate_prescription(medicines: List[Dict[str, Any]], patient_history: Dict[str, Any] = None) -> Dict[str, Any]:
    alerts = []
    if patient_history is None:
        patient_history = {}
    
    # 1. Sulfa Allergy Check (Critical CDSS Rule)
    flagged_sulfa = []
    for med in medicines:
        med_name = med.get("name", "").lower()
        if any(s in med_name for s in SULFA_DRUGS):
            flagged_sulfa.append(med.get("name"))

    if flagged_sulfa:
        alerts.append({
            "id": "CDSS-SULFA-ALLERGY-01",
            "type": "CONTRAINDICATION",
            "severity": "CRITICAL",
            "title": "CRITICAL CDSS ALERT: Severe Sulfa Drug Hypersensitivity",
            "description": "Patient's past OCR record indicates severe allergy to Sulfa-based drugs. Avoid Sulfadoxine-Pyrimethamine.",
            "flagged_items": flagged_sulfa,
            "evidence_source": "Civil Hospital Emergency Discharge Slip (Oct 2024 OCR Record)",
            "clinical_rationale": "Patient experienced acute urticaria and angioedema with Septran (Co-trimoxazole). Sulfa-based antimalarials pose high anaphylactic risk.",
            "recommended_alternative": "Artemether-Lumefantrine 80/480mg (ACT) or Artesunate-Amodiaquine"
        })

    return {
        "status": "FLAGGED" if alerts else "CLEARED",
        "has_critical": any(a["severity"] == "CRITICAL" for a in alerts),
        "alerts_count": len(alerts),
        "alerts": alerts
    }
